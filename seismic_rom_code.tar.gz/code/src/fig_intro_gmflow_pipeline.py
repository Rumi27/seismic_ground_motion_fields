"""Figure: GMFlow data source — simplified for manuscript.

Shows only: source parameters → GMFlow → dense wavefield → this study.
All internal notation (ODE, decoder symbols, operator symbols) removed.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from pathlib import Path

ROOT = Path(__file__).parents[1]
OUT = ROOT / "results/figures/fig_intro_gmflow_pipeline.pdf"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": 9,
    "font.weight": "normal",
    "axes.titleweight": "normal",
})

# ── canvas ──────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(12, 3.8))
ax.set_xlim(0, 12)
ax.set_ylim(0, 3.8)
ax.axis("off")


def rbox(cx, cy, w, h, text, fc="#f8f8f8", ec="#555555",
         fontsize=8.8, lw=1.0):
    ax.add_patch(FancyBboxPatch(
        (cx - w / 2, cy - h / 2), w, h,
        boxstyle="round,pad=0.15", fc=fc, ec=ec, lw=lw, zorder=3))
    ax.text(cx, cy, text, ha="center", va="center",
            fontsize=fontsize, linespacing=1.6, zorder=4)


def arr(x1, y1, x2, y2, color="#444444", lw=1.2, ls="-"):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(
                    arrowstyle="-|>", color=color, lw=lw,
                    mutation_scale=12, linestyle=ls,
                    connectionstyle="arc3,rad=0.0"),
                zorder=5)


# ── Stage 1 background ──────────────────────────────────────────────────────
ax.add_patch(FancyBboxPatch(
    (0.18, 0.50), 8.44, 3.10,
    boxstyle="round,pad=0.1", fc="#dbeafe", ec="#93c5fd", lw=1.1, zorder=0))
ax.text(4.40, 3.50, "Stage 1 — Source-conditioned synthesis",
        ha="center", va="bottom", fontsize=9, color="#1e3a8a", style="italic")

# ── Stage 2 background ──────────────────────────────────────────────────────
ax.add_patch(FancyBboxPatch(
    (8.82, 0.50), 2.98, 3.10,
    boxstyle="round,pad=0.1", fc="#dcfce7", ec="#86efac", lw=1.1, zorder=0))
ax.text(10.31, 3.50, "Stage 2 — Super-resolution",
        ha="center", va="bottom", fontsize=9, color="#14532d", style="italic")

# ── Boxes ────────────────────────────────────────────────────────────────────
# Input
rbox(1.55, 2.05, 2.50, 0.86,
     "Event source parameters\n(Mw, hypocenter, rupture velocity)",
     fc="#bfdbfe", ec="#3b82f6", fontsize=8.8)

# Stage 1: generation
rbox(4.40, 2.05, 2.40, 2.10,
     "Source-conditioned\nlatent generation",
     fc="#eff6ff", ec="#3b82f6", lw=1.25, fontsize=9.0)

# Stage 1: decoder
rbox(7.10, 2.05, 1.90, 0.86,
     "Latent\ndecoder",
     fc="#dbeafe", ec="#2563eb", lw=1.1, fontsize=8.8)

# Stage 2: super-resolution
rbox(10.31, 2.68, 2.50, 0.82,
     "Super-resolution\nneural operator",
     fc="#bbf7d0", ec="#22c55e", lw=1.1, fontsize=8.8)

# Stage 2: output field
rbox(10.31, 1.42, 2.50, 0.86,
     "Dense wavefield\n(0 – 1 Hz, 62,757 stations)",
     fc="#86efac", ec="#16a34a", lw=1.5, fontsize=8.8)

# ── Arrows ────────────────────────────────────────────────────────────────────
arr(2.80, 2.05, 3.20, 2.05)          # source params → generation
arr(5.60, 2.05, 6.15, 2.05)          # generation → decoder
arr(8.05, 2.05, 8.86, 2.45)          # decoder → super-res (diagonal up)
arr(10.31, 2.27, 10.31, 1.85, color="#166534")  # super-res → output field

# ── "This study" annotation ──────────────────────────────────────────────────
ax.annotate("", xy=(10.31, 0.78), xytext=(10.31, 1.00),
            arrowprops=dict(arrowstyle="-|>", color="#166534", lw=1.1,
                            mutation_scale=10, linestyle="dashed"),
            zorder=5)
ax.text(10.31, 0.64,
        "underlying physics simulation fields\nused as reference data in this study",
        ha="center", va="top", fontsize=7.8, color="#166534", style="italic",
        linespacing=1.5)

# ── Footnote ─────────────────────────────────────────────────────────────────
ax.text(4.40, 0.64,
        "Real seismometer observations are not used during GMFlow inference.",
        ha="center", va="top", fontsize=7.8, color="#555555", style="italic")

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
