"""Figure: Proposed methodology workflow — simplified for manuscript.

Shows: Training phase (simulation → POD basis) and Reconstruction phase
(sparse observations → gappy POD → full field).
All equations, matrix dimensions, and result annotations removed.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from pathlib import Path

ROOT = Path(__file__).parents[1]
OUT = ROOT / "results/figures/fig_intro_methodology_workflow.pdf"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": 9,
    "font.weight": "normal",
    "axes.titleweight": "normal",
})

# ── canvas ───────────────────────────────────────────────────────────────────
W, H = 14.0, 8.5
fig, ax = plt.subplots(figsize=(W, H))
ax.set_xlim(0, W)
ax.set_ylim(0, H)
ax.axis("off")

# ── helpers ───────────────────────────────────────────────────────────────────
BW = 4.2
BH = 0.82


def rbox(cx, cy, w, h, text, fc="#f8f8f8", ec="#555555",
         fontsize=8.8, lw=1.0):
    ax.add_patch(FancyBboxPatch(
        (cx - w / 2, cy - h / 2), w, h,
        boxstyle="round,pad=0.13", fc=fc, ec=ec, lw=lw, zorder=3))
    ax.text(cx, cy, text, ha="center", va="center",
            fontsize=fontsize, linespacing=1.55, zorder=4)


def arr(x1, y1, x2, y2, color="#444444", lw=1.1,
        cs="arc3,rad=0.0", ls="-"):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(
                    arrowstyle="-|>", color=color, lw=lw,
                    mutation_scale=11,
                    linestyle=ls,
                    connectionstyle=cs),
                zorder=5)


# ── zone backgrounds ─────────────────────────────────────────────────────────
ax.add_patch(FancyBboxPatch(
    (0.22, 0.50), 6.06, 7.78,
    boxstyle="round,pad=0.1", fc="#e8eef7", ec="#7a93cc", lw=1.1, zorder=0))
ax.text(3.25, 8.20, "Training Phase",
        ha="center", va="bottom", fontsize=10.5, color="#1a2e5a",
        style="italic")

ax.add_patch(FancyBboxPatch(
    (7.72, 0.50), 6.06, 7.78,
    boxstyle="round,pad=0.1", fc="#e7f5ed", ec="#6aaa82", lw=1.1, zorder=0))
ax.text(10.75, 8.20, "Reconstruction Phase",
        ha="center", va="bottom", fontsize=10.5, color="#1a4a2e",
        style="italic")

# ── Training column (cx=3.25) ─────────────────────────────────────────────────
CXT = 3.25
y_train = [7.52, 6.38, 5.24, 4.00]

# 1. Simulation ensemble
rbox(CXT, y_train[0], BW + 0.3, BH,
     "SW4/GMFlow simulation ensemble\n(Mw 7.0 events, 62,757 virtual stations)",
     fc="#c5d8f0", ec="#3a6aaa")

# 2. Frequency filtering
rbox(CXT, y_train[1], BW, BH,
     "Frequency filtering\n(0 – 0.25 Hz band-pass)",
     fc="#d8e6f5", ec="#5577aa")

# 3. POD basis computation (encompasses snapshot assembly + SVD)
rbox(CXT, y_train[2], BW, BH,
     "POD basis computation\n(SVD of snapshot matrix)",
     fc="#d8e6f5", ec="#5577aa")

# 4. POD basis — bridge node
rbox(CXT, y_train[3], BW + 0.5, BH + 0.18,
     "POD basis  $\\mathbf{V}_r$",
     fc="#b3ccea", ec="#1e4d99", lw=1.7, fontsize=10.5)

# Downward arrows in training column
for i in range(len(y_train) - 1):
    arr(CXT, y_train[i] - BH / 2,
        CXT, y_train[i + 1] + BH / 2 + 0.08,
        color="#2a5590")

# OpInf diagnostic — dashed side branch below POD basis
y_opinf = 2.72
rbox(CXT, y_opinf, BW, BH,
     "OpInf diagnostic\n(source-forced operator inference)",
     fc="#c8d9ed", ec="#3355aa", lw=1.0, fontsize=8.8)
arr(CXT, y_train[3] - (BH + 0.18) / 2,
    CXT, y_opinf + BH / 2 + 0.08,
    color="#3355aa", lw=1.0, ls="dashed")
ax.text(CXT + 2.40, y_opinf,
        "diagnostic\nbaseline",
        ha="left", va="center", fontsize=7.5, color="#3355aa", style="italic")

# ── Reconstruction column (cx=10.75) ─────────────────────────────────────────
CXR = 10.75
y_recon = [7.52, 6.38, 5.28, 4.18, 3.08, 1.98]
recon_heights = [BH, BH + 0.22, BH, BH, BH, BH]

# 1. Sparse observations
rbox(CXR, y_recon[0], BW + 0.3, BH,
     "Sparse seismometer observations\n($n_{\\mathrm{obs}}$ stations,  3 components each)",
     fc="#b2ddc8", ec="#2e8a55")

# 2. Station layout selection
rbox(CXR, y_recon[1], BW, BH + 0.22,
     "Station layout selection\n(Random · POD-QR · NCSN-derived)",
     fc="#c9ead8", ec="#44997a")

# 3. Observed POD rows
rbox(CXR, y_recon[2], BW, BH,
     "Observed POD rows  $\\mathbf{V}_{\\mathrm{obs}}$\n"
     "(rows of  $\\mathbf{V}_r$  at observed stations)",
     fc="#c9ead8", ec="#44997a")

# 4. Observability diagnostics
rbox(CXR, y_recon[3], BW, BH,
     "Observability diagnostics\n"
     "($\\sigma_{\\mathrm{min}}$ and condition number of  $\\mathbf{V}_{\\mathrm{obs}}$)",
     fc="#c9ead8", ec="#44997a", fontsize=8.5)

# 5. Gappy POD coefficient recovery
rbox(CXR, y_recon[4], BW, BH,
     "Gappy POD coefficient recovery\n(Tikhonov-regularised least squares)",
     fc="#c9ead8", ec="#44997a")

# 6. Full-field reconstruction + error evaluation
rbox(CXR, y_recon[5], BW, BH,
     "Full-field reconstruction + error evaluation\n(all 62,757 stations)",
     fc="#b2ddc8", ec="#1e7a46", lw=1.4)

# Downward arrows in reconstruction column
for i in range(len(y_recon) - 1):
    arr(CXR, y_recon[i] - recon_heights[i] / 2,
        CXR, y_recon[i + 1] + recon_heights[i + 1] / 2 + 0.08,
        color="#226644")

# ── Bridge arrow: POD basis → observed POD rows ───────────────────────────────
x_start = CXT + (BW + 0.5) / 2
y_start = y_train[3]
x_end   = CXR - BW / 2
y_end   = y_recon[2]

arr(x_start, y_start, x_end, y_end,
    color="#1e4d99", lw=1.4, cs="arc3,rad=-0.20")

ax.text(7.0, 4.82,
        "$\\mathbf{V}_r$",
        ha="center", va="center", fontsize=11, color="#1e4d99",
        fontstyle="italic",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#1e4d99",
                  lw=0.8, alpha=0.92),
        zorder=6)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
