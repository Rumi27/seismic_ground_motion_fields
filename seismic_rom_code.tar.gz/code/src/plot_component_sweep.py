"""Three-panel comparison: 3-component vs 2-component (horizontal-only) observations.

Panels
------
  Left  — relative waveform error vs n_observed (random mean ± std, farthest)
  Middle — relative PGV error vs n_observed
  Right  — condition number of V_obs vs n_observed (log scale)

Vertical annotations mark the OD=1 and OD=2.54 thresholds for each component
mode, shifted rightward by the factor 3/2 for 2-component observations:
    OD=1:    n* = ⌈r/3⌉ = 51 (3-comp)   n* = ⌈r/2⌉ = 76 (2-comp)
    OD=2.54: n  =  128      (3-comp)   n  =  192      (2-comp)

Usage
-----
    python -m src.plot_component_sweep
    python -m src.plot_component_sweep --input-csv path/to/sweep.csv
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.lines as mlines
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .config import RESULTS_TABLES

FONT_SIZE = 11
LEGEND_FONT_SIZE = 9
ANNOT_FONT_SIZE = 9
plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
        "font.size": FONT_SIZE,
        "font.weight": "normal",
        "axes.labelsize": FONT_SIZE,
        "axes.titlesize": FONT_SIZE,
        "axes.titleweight": "normal",
        "xtick.labelsize": FONT_SIZE,
        "ytick.labelsize": FONT_SIZE,
        "legend.fontsize": FONT_SIZE,
    }
)

DEFAULT_INPUT  = RESULTS_TABLES / "station_count_sweep_components.csv"
DEFAULT_OUTPUT = Path("results/figures/station_count_components.pdf")

RANK  = 151
N_3   = 3
N_2   = 2

# OD thresholds
OD1_3   = round(RANK / N_3)           # 50
OD254_3 = round(2.54 * RANK / N_3)    # 128
OD1_2   = round(RANK / N_2)           # 76
OD254_2 = round(2.54 * RANK / N_2)    # 192

COLORS = {3: "#1f77b4", 2: "#d62728"}   # blue / red
LS_RAND = "-"
LS_FAR  = "--"

METRICS = [
    ("mean_rel_error_heldout", "Relative waveform error (held-out)"),
    ("mean_pgv_error_heldout", "Relative PGV error (held-out)"),
    ("mean_cond_vobs",         r"Condition number of $V_\mathrm{obs}$"),
]


def _rand_stats(df: pd.DataFrame, n_comp: int, metric: str) -> pd.DataFrame:
    sub = df[(df["layout"] == "random") & (df["n_obs_comp"] == n_comp)]
    return (
        sub.groupby("n_observed_stations")[metric]
        .agg(["mean", "std"])
        .reset_index()
    )


def _far_curve(df: pd.DataFrame, n_comp: int, metric: str) -> pd.DataFrame:
    return (
        df[(df["layout"] == "farthest") & (df["n_obs_comp"] == n_comp)]
        .sort_values("n_observed_stations")
        [["n_observed_stations", metric]]
    )


def _vline(ax, x, color, label):
    ax.axvline(x, color=color, ls=":", lw=0.85, alpha=0.65)
    ylim = ax.get_ylim()
    y_text = ylim[0] + 0.04 * (ylim[1] - ylim[0])
    ax.text(x + 4, y_text, label, fontsize=ANNOT_FONT_SIZE, va="bottom", color=color, alpha=0.85)


def plot(input_csv: Path, output_path: Path) -> None:
    df = pd.read_csv(input_csv)
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.5))

    for ax, (metric, ylabel) in zip(axes, METRICS):
        use_log = metric == "mean_cond_vobs"
        for n_comp in (3, 2):
            color = COLORS[n_comp]
            label_base = f"{n_comp}-comp"

            rand = _rand_stats(df, n_comp, metric)
            if not rand.empty:
                if use_log:
                    ax.semilogy(rand["n_observed_stations"], rand["mean"],
                                color=color, lw=1.8, ls=LS_RAND, zorder=3)
                    ax.fill_between(
                        rand["n_observed_stations"],
                        (rand["mean"] - rand["std"]).clip(1),
                        rand["mean"] + rand["std"],
                        color=color, alpha=0.15, zorder=2,
                    )
                else:
                    ax.plot(rand["n_observed_stations"], rand["mean"],
                            color=color, lw=1.8, ls=LS_RAND, zorder=3,
                            label=f"{label_base} random")
                    ax.fill_between(
                        rand["n_observed_stations"],
                        rand["mean"] - rand["std"],
                        rand["mean"] + rand["std"],
                        color=color, alpha=0.15, zorder=2,
                    )

            far = _far_curve(df, n_comp, metric)
            if not far.empty:
                if use_log:
                    ax.semilogy(far["n_observed_stations"], far[metric],
                                color=color, lw=1.6, ls=LS_FAR, zorder=3)
                else:
                    ax.plot(far["n_observed_stations"], far[metric],
                            color=color, lw=1.6, ls=LS_FAR, zorder=3,
                            label=f"{label_base} farthest")

        # OD annotation lines
        if not use_log:
            _vline(ax, OD1_3,   COLORS[3], f"OD=1\n(n={OD1_3},3c)")
            _vline(ax, OD1_2,   COLORS[2], f"OD=1\n(n={OD1_2},2c)")
            _vline(ax, OD254_3, COLORS[3], f"OD=2.54\n(n={OD254_3},3c)")
            _vline(ax, OD254_2, COLORS[2], f"OD=2.54\n(n={OD254_2},2c)")
            ax.set_ylim(bottom=0)
        else:
            _vline(ax, OD1_3,   COLORS[3], f"{OD1_3}\n3c")
            _vline(ax, OD1_2,   COLORS[2], f"{OD1_2}\n2c")
            _vline(ax, OD254_3, COLORS[3], f"{OD254_3}\n3c")
            _vline(ax, OD254_2, COLORS[2], f"{OD254_2}\n2c")

        ax.set_xlabel("Number of observed stations")
        ax.set_ylabel(ylabel)
        ax.set_xlim(left=0)
        ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.5)
        ax.tick_params()

    # Legend: component colour + linestyle meaning
    legend_handles = [
        mpatches.Patch(color=COLORS[3], alpha=0.7, label="3-comp (x,y,z)"),
        mpatches.Patch(color=COLORS[2], alpha=0.7, label="2-comp horiz. (x,y)"),
        mlines.Line2D([], [], color="grey", ls=LS_RAND, lw=1.6, label="Random (mean ± std)"),
        mlines.Line2D([], [], color="grey", ls=LS_FAR,  lw=1.6, label="Farthest-point"),
    ]
    axes[0].legend(
        handles=legend_handles,
        fontsize=LEGEND_FONT_SIZE,
        loc="upper right",
        labelspacing=0.3,
    )

    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    fig.savefig(output_path.with_suffix(".png"), dpi=150, bbox_inches="tight")
    print(f"Saved → {output_path}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input-csv",  type=Path, default=DEFAULT_INPUT)
    p.add_argument("--output-pdf", type=Path, default=DEFAULT_OUTPUT)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    plot(args.input_csv, args.output_pdf)


if __name__ == "__main__":
    main()
