"""Figure: Cross-method reconstruction summary for Discussion section."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as mpatches
from pathlib import Path

FONT_SIZE = 11
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": FONT_SIZE, "axes.labelsize": FONT_SIZE,
    "axes.titlesize": FONT_SIZE, "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "font.weight": "normal", "axes.titleweight": "normal",
})

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results/figures/fig_discussion_summary.pdf"

# ── data ───────────────────────────────────────────────────────────────────
# All values: rank 151, 128 stations, Mw7 low-frequency, global domain
# std=0 means single seed; NaN means metric not measured

methods = [
    # (label, group, wf_mean, wf_std, pgv_mean, pgv_std)
    # Listed worst-to-best so y=0 (bottom) is worst; y-axis will be inverted
    # ── Interpolation baselines ──────────────────────────────────
    ("Mean-field",          "base", 0.9894, 0.0007, 1.0000, 0.0000),
    ("IDW",                 "base", 0.7656, 0.0025, 0.6313, 0.0052),
    ("GP kriging",          "base", np.nan,  np.nan, 0.5045, 0.1428),
    ("Nearest station",     "base", 0.8557, 0.0071, 0.4112, 0.0105),
    # ── Gappy POD ────────────────────────────────────────────────
    ("NCSN-real\n(global)", "gpod", 1.2590, 0.0000, 0.6070, 0.0000),
    ("NCSN-real\n(0–10 km)","gpod", 0.7482, 0.0000, 0.3855, 0.0000),
    ("Random",              "gpod", 0.2685, 0.0096, 0.1047, 0.0057),
    ("Farthest-point",      "gpod", 0.2516, 0.0056, 0.1014, 0.0041),
    ("POD-QR",              "gpod", 0.2278, 0.0095, 0.0830, 0.0046),
]

labels   = [m[0] for m in methods]
groups   = [m[1] for m in methods]
wf_m     = np.array([m[2] for m in methods], dtype=float)
wf_s     = np.array([m[3] for m in methods], dtype=float)
pgv_m    = np.array([m[4] for m in methods], dtype=float)
pgv_s    = np.array([m[5] for m in methods], dtype=float)

n = len(methods)
y = np.arange(n)

C_GPOD = "#2166ac"   # blue family for gappy POD
C_BASE = "#888888"   # grey for baselines

dot_colors = [C_GPOD if g == "gpod" else C_BASE for g in groups]

# background band indices
gpod_idx = [i for i, g in enumerate(groups) if g == "gpod"]
base_idx  = [i for i, g in enumerate(groups) if g == "base"]

# ── figure ─────────────────────────────────────────────────────────────────
fig, (ax_wf, ax_pgv) = plt.subplots(1, 2, figsize=(11.5, 4.8))
fig.subplots_adjust(left=0.22, right=0.93, top=0.88, bottom=0.12, wspace=0.38)

for ax, vals, errs, title, xlabel, xlim in [
    (ax_wf,  wf_m,  wf_s,
     "(a)  Waveform error", "Relative waveform error", (-0.05, 1.45)),
    (ax_pgv, pgv_m, pgv_s,
     "(b)  PGV error",      "Relative PGV error",      (-0.05, 1.25)),
]:
    # group background bands
    gpod_lo = min(gpod_idx) - 0.5
    gpod_hi = max(gpod_idx) + 0.5
    base_lo = min(base_idx) - 0.5
    base_hi = max(base_idx) + 0.5
    ax.axhspan(gpod_lo, gpod_hi, color="#dce9f5", alpha=0.55, zorder=0)
    ax.axhspan(base_lo, base_hi, color="#f0f0f0", alpha=0.55, zorder=0)

    # mean-field reference line
    ax.axvline(1.0, color="#555555", lw=0.9, ls="--", zorder=1)

    # stem lines (horizontal)
    for i, (v, e) in enumerate(zip(vals, errs)):
        if np.isnan(v):
            continue
        color = dot_colors[i]
        ax.plot([0, v], [y[i], y[i]], color=color, lw=1.2, alpha=0.5, zorder=2)
        # error bar
        if e > 0:
            ax.plot([v - e, v + e], [y[i], y[i]], color=color, lw=2.0, zorder=3)
            ax.plot([v - e, v - e], [y[i] - 0.18, y[i] + 0.18],
                    color=color, lw=2.0, zorder=3)
            ax.plot([v + e, v + e], [y[i] - 0.18, y[i] + 0.18],
                    color=color, lw=2.0, zorder=3)
        # dot
        mstyle = "o" if groups[i] == "gpod" else "D"
        ax.plot(v, y[i], marker=mstyle, ms=8, color=color,
                markeredgecolor="white", markeredgewidth=0.6, zorder=4)

    # value annotations
    for i, (v, e) in enumerate(zip(vals, errs)):
        if np.isnan(v):
            ax.text(xlim[0] + 0.03, y[i], "N/A",
                    va="center", fontsize=8, color="#aaaaaa", style="italic")
            continue
        offset = e + 0.025 if e > 0 else 0.025
        ha = "left"
        txt = f"{v:.3f}"
        ax.text(v + offset, y[i], txt,
                va="center", ha=ha, fontsize=8, color=dot_colors[i])

    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=9.5)
    ax.set_xlim(xlim)
    ax.set_ylim(n - 0.4, -0.6)   # inverted: best at top
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(axis="y", length=0)

    # group labels — placed in axes-fraction coords so they never clip
    mid_gpod = (gpod_lo + gpod_hi) / 2
    mid_base = (base_lo + base_hi) / 2
    # convert data y → axes fraction (y-axis is inverted: top=n-0.4, bottom=-0.6)
    y_range = (n - 0.4) - (-0.6)   # total span in data coords (inverted)
    def to_ax_y(data_y):
        # axes fraction: 0=bottom (data n-0.4), 1=top (data -0.6)
        return 1.0 - (data_y - (-0.6)) / y_range
    ax.text(1.02, to_ax_y(mid_gpod), "Gappy\nPOD",
            transform=ax.transAxes, va="center", ha="left",
            fontsize=8, color=C_GPOD, linespacing=1.3)
    ax.text(1.02, to_ax_y(mid_base), "Baselines",
            transform=ax.transAxes, va="center", ha="left",
            fontsize=8, color="#666666")


# legend
h_gpod = mlines.Line2D([], [], color=C_GPOD, marker="o", ms=7,
                        markeredgecolor="white", lw=1.2,
                        label="Gappy POD (this work)")
h_base = mlines.Line2D([], [], color=C_BASE, marker="D", ms=7,
                        markeredgecolor="white", lw=1.2,
                        label="Interpolation baseline")
h_mf   = mlines.Line2D([], [], color="#555555", lw=0.9, ls="--",
                        label="Mean-field baseline")
ax_wf.legend(handles=[h_gpod, h_base, h_mf],
             fontsize=8.5, loc="lower right", framealpha=0.9,
             handlelength=1.6, borderpad=0.5)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
