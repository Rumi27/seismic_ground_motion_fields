"""Plot rank vs validation rollout error from OpInf sweeps."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from .config import RESULTS_FIGURES, RESULTS_TABLES


def plot_rank_vs_rollout(
    df: pd.DataFrame,
    output_path: Path,
    title_suffix: str = "",
) -> None:
    fig, ax = plt.subplots(figsize=(8, 4.5))
    lambdas = sorted(df["lambda"].unique())
    cmap = plt.cm.plasma

    for idx, lam in enumerate(lambdas):
        sub = df[df["lambda"] == lam].sort_values("rank")
        ax.plot(
            sub["rank"],
            sub["val_rollout"],
            marker="o",
            linewidth=1.8,
            color=cmap(idx / max(len(lambdas) - 1, 1)),
            label=f"λ = {lam:g}",
        )

    ax.set_xlabel("POD rank")
    ax.set_ylabel("Validation rollout error (relative Frobenius)")
    title = "Low-frequency Mw7 OpInf: rank vs autonomous rollout error"
    if title_suffix:
        title = f"{title} ({title_suffix})"
    ax.set_title(title)
    ax.set_xticks(sorted(df["rank"].unique()))
    ax.grid(alpha=0.3)
    ax.legend(title="Ridge λ", fontsize=8, loc="upper left")
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path)
    plt.close(fig)
    print(f"Wrote {output_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        type=Path,
        default=RESULTS_TABLES / "lowfreq_opinf_sweep_mw7_strong_regularization.csv",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=RESULTS_FIGURES / "lowfreq_opinf_rank_vs_rollout_error.pdf",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    df = pd.read_csv(args.input)
    plot_rank_vs_rollout(df, args.output, title_suffix="strong ridge sweep")


if __name__ == "__main__":
    main()
