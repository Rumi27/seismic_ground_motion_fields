"""Figure: Frequency filtering schematic for Methods section.

Creates a 3-panel figure showing:
  left   – example raw time-domain waveform
  middle – FFT amplitude spectrum with 4 band masks
  right  – filtered waveforms for each band (stacked)
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
from pathlib import Path

OUT = Path(__file__).parents[1] / "results" / "figures" / "fig_methods_freq_filtering.pdf"

# ── simulation parameters ──────────────────────────────────────────────────
N = 118
DT = 0.2534854          # seconds per sample
T = np.arange(N) * DT  # 0 to ~29.9 s
DF = 1.0 / (N * DT)    # ≈ 0.0334 Hz per bin
FREQS = np.fft.rfftfreq(N, d=DT)

# Actual bin ranges from manuscript
BANDS = {
    "Full\n(0–1 Hz)":        (0,  30, "#444444"),
    "Low\n(0–0.25 Hz)":      (0,   8, "#2166ac"),
    "Mid\n(0.25–0.5 Hz)":    (7,  14, "#4dac26"),
    "High\n(0.5–1 Hz)":     (15,  30, "#d6604d"),
}
BAND_LABELS  = list(BANDS.keys())
BAND_BINS    = [(v[0], v[1]) for v in BANDS.values()]
BAND_COLORS  = [v[2] for v in BANDS.values()]

# ── synthetic seismic waveform ─────────────────────────────────────────────
rng = np.random.default_rng(7)
# Gaussian-modulated mixture resembling a band-limited seismic record
def make_synthetic(t, seed_offset=0):
    sig = np.zeros_like(t)
    # Main P-wave arrival
    sig += 0.4 * np.exp(-((t - 6) ** 2) / (2 * 0.8**2)) * np.sin(2 * np.pi * 0.22 * t)
    # S-wave + coda
    sig += 1.0 * np.exp(-((t - 11) ** 2) / (2 * 2.0**2)) * np.sin(2 * np.pi * 0.15 * t + 0.5 + seed_offset)
    sig += 0.6 * np.exp(-((t - 14) ** 2) / (2 * 2.5**2)) * np.sin(2 * np.pi * 0.35 * t + 1.0 + seed_offset)
    sig += 0.3 * np.exp(-((t - 18) ** 2) / (2 * 3.0**2)) * np.sin(2 * np.pi * 0.65 * t + 0.2 + seed_offset)
    sig += 0.12 * rng.standard_normal(len(t)) * np.exp(-t / 15)
    return sig

raw = make_synthetic(T)

def brickwall_filter(signal, bin_lo, bin_hi):
    spec = np.fft.rfft(signal)
    mask = np.zeros(len(spec))
    mask[bin_lo:bin_hi] = 1.0
    return np.fft.irfft(spec * mask, n=N)

filtered = [brickwall_filter(raw, lo, hi) for (lo, hi) in BAND_BINS]
spectrum = np.abs(np.fft.rfft(raw))

# ── plotting ───────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(11, 4.2))
fig.subplots_adjust(left=0.065, right=0.985, top=0.93, bottom=0.13, wspace=0.38)

gs = GridSpec(1, 3, figure=fig, width_ratios=[1.6, 1.6, 1.8])
ax_raw  = fig.add_subplot(gs[0])
ax_spec = fig.add_subplot(gs[1])
ax_filt = fig.add_subplot(gs[2])

# panel A – raw waveform
ax_raw.plot(T, raw, color="#333333", lw=0.9)
ax_raw.axhline(0, color="#aaaaaa", lw=0.5, zorder=0)
ax_raw.set_xlabel("Time  (s)", fontsize=9)
ax_raw.set_ylabel("Displacement (normalised)", fontsize=9)
ax_raw.set_title("(a)  Raw waveform", fontsize=9, fontweight="bold")
ax_raw.set_xlim(T[0], T[-1])
ax_raw.tick_params(labelsize=8)

# panel B – FFT spectrum with band masks
ax_spec.plot(FREQS, spectrum, color="#333333", lw=1.0, zorder=3)
# shade each band
band_shade_alpha = 0.25
for (lo, hi), col, lbl in zip(BAND_BINS[1:], BAND_COLORS[1:], BAND_LABELS[1:]):
    f_lo = FREQS[lo]
    f_hi = FREQS[min(hi - 1, len(FREQS) - 1)]
    ax_spec.axvspan(f_lo, f_hi, alpha=band_shade_alpha, color=col, zorder=1)
    ax_spec.axvline(f_lo, color=col, lw=0.8, ls="--", zorder=2)
    ax_spec.axvline(f_hi, color=col, lw=0.8, ls="--", zorder=2)

# nominal band edges
for fnom, lbl in [(0.25, "0.25"), (0.5, "0.5"), (1.0, "1.0")]:
    ax_spec.axvline(fnom, color="#888888", lw=0.6, ls=":", zorder=2)

ax_spec.set_xlabel("Frequency  (Hz)", fontsize=9)
ax_spec.set_ylabel("|FFT amplitude|", fontsize=9)
ax_spec.set_title("(b)  FFT spectrum & band masks", fontsize=9, fontweight="bold")
ax_spec.set_xlim(0, 1.1)
ax_spec.tick_params(labelsize=8)
# legend patches
patches = [mpatches.Patch(color=c, alpha=0.55, label=l.replace("\n", " "))
           for c, l in zip(BAND_COLORS[1:], BAND_LABELS[1:])]
ax_spec.legend(handles=patches, fontsize=7, loc="upper right",
               framealpha=0.85, handlelength=1.2, borderpad=0.5)

# panel C – filtered waveforms stacked
labels_short = ["Full (0–1 Hz)", "Low (0–0.25 Hz)", "Mid (0.25–0.5 Hz)", "High (0.5–1 Hz)"]
offsets = [3.0, 1.0, -1.0, -3.0]  # vertical offsets for stacking
for sig, off, col, lbl in zip(filtered, offsets, BAND_COLORS, labels_short):
    sig_n = sig / (np.max(np.abs(sig)) + 1e-9) * 0.82  # normalise amplitude
    ax_filt.plot(T, sig_n + off, color=col, lw=0.9)
    ax_filt.axhline(off, color="#dddddd", lw=0.4, zorder=0)
    ax_filt.text(T[-1] + 0.4, off, lbl, va="center", ha="left",
                 fontsize=7, color=col)

ax_filt.set_xlabel("Time  (s)", fontsize=9)
ax_filt.set_title("(c)  Band-filtered waveforms", fontsize=9, fontweight="bold")
ax_filt.set_xlim(T[0], T[-1])
ax_filt.set_ylim(-4.5, 4.5)
ax_filt.set_yticks([])
ax_filt.tick_params(labelsize=8)

for ax in (ax_raw, ax_spec, ax_filt):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
