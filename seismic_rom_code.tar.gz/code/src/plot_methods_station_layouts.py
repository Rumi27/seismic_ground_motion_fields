"""Figure: Station layout comparison for Methods section.

4-panel map (simulation domain coordinates) showing:
  (a) Random uniform    (b) Farthest-point
  (c) NCSN-real         (d) POD-QR
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
from pathlib import Path
import pandas as pd
from scipy.linalg import qr
import geopandas as gpd
from shapely.geometry import box as sbox
from shapely.ops import unary_union

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results" / "figures" / "fig_methods_station_layouts.pdf"

# ── domain geometry ────────────────────────────────────────────────────────
N_I, N_J = 367, 171          # simulation station grid dimensions
N_STATIONS = N_I * N_J       # 62,757
N_COMPONENTS = 3
LX, LY = 73.0, 43.0          # domain km

def flat_to_km(flat_idx):
    i0 = flat_idx // N_J     # 0-based
    j0 = flat_idx % N_J
    return i0 / (N_I - 1) * LX, j0 / (N_J - 1) * LY

# Full grid (x, y) in km
all_i0 = np.arange(N_STATIONS) // N_J
all_j0 = np.arange(N_STATIONS) % N_J
all_x  = all_i0 / (N_I - 1) * LX
all_y  = all_j0 / (N_J - 1) * LY

# ── station selection ──────────────────────────────────────────────────────
N_OBS = 128; SEED = 42

def select_random(seed=SEED):
    return np.sort(np.random.default_rng(seed).choice(N_STATIONS, N_OBS, replace=False))

def select_farthest(seed=SEED):
    rng = np.random.default_rng(seed)
    xy  = np.stack([all_x, all_y], 1)
    sel = [int(rng.integers(N_STATIONS))]
    dists = np.full(N_STATIONS, np.inf)
    while len(sel) < N_OBS:
        d = np.hypot(xy[:, 0] - xy[sel[-1], 0], xy[:, 1] - xy[sel[-1], 1])
        dists = np.minimum(dists, d)
        dists[sel] = -1
        sel.append(int(np.argmax(dists)))
    return np.sort(np.array(sel, np.int64))

def select_ncsn():
    df  = pd.read_csv(ROOT / "data/processed/ncsn_station_mapping.csv")
    col = "nearest_station_index"
    idx = df[col].dropna().astype(np.int64).drop_duplicates().to_numpy()
    return np.sort(idx[(idx >= 0) & (idx < N_STATIONS)][:N_OBS])

def select_pod_qr():
    V_full = np.load(ROOT / "outputs/lowfreq_opinf_mw7_rank151_baseline/V.npy")
    V = V_full[:, :50].astype(np.float64)
    blk  = V.reshape(N_COMPONENTS, N_STATIONS, 50)
    qmat = blk.transpose(2, 0, 1).reshape(150, N_STATIONS)
    _, _, piv = qr(qmat, mode="economic", pivoting=True, check_finite=False)
    return np.sort(piv[:N_OBS].astype(np.int64))

print("Computing layouts ...")
idx_random   = select_random()
idx_farthest = select_farthest()
idx_ncsn     = select_ncsn()
print("POD-QR ...")
idx_podqr    = select_pod_qr()
print("Done.")

# ── Hayward Fault schematic (domain-aligned, roughly centre of domain) ─────
# Fault runs NNW-SSE through the centre at roughly x=36 km (centre of 73 km)
_cx = LX / 2
fault_x = np.array([_cx - 4, _cx - 1, _cx + 2, _cx + 5])
fault_y = np.array([40, 29, 17, 6])

# ── geographic background (approximate: x ≈ S→N along-fault, y ≈ E→W across) ─
# Domain corners (inset-rectangle derived):
#   x=0→lat 37.38  x=73→lat 38.03   y=0→lon -121.85   y=43→lon -122.34
_GEO_LAT0, _GEO_LAT1 = 37.38, 38.03
_GEO_LON_E, _GEO_LON_W = -121.85, -122.34

def _geo_to_km(lats, lons):
    x = (np.asarray(lats) - _GEO_LAT0) / (_GEO_LAT1 - _GEO_LAT0) * LX
    y = (np.asarray(lons) - _GEO_LON_E) / (_GEO_LON_W - _GEO_LON_E) * LY
    return x, y

_ne_shp_land = ROOT / "data/raw/ne_50m_land/ne_50m_land.shp"
_geo_land_poly = None
try:
    _raw_land = gpd.read_file(str(_ne_shp_land))
    _clip_box = sbox(-122.55, 37.28, -121.70, 38.12)
    _clipped = _raw_land[_raw_land.geometry.intersects(_clip_box)].copy()
    _clipped["geometry"] = _clipped.geometry.intersection(_clip_box)
    _merged = unary_union(_clipped.geometry)
    if hasattr(_merged, "geoms"):
        _geo_land_poly = unary_union([g for g in _merged.geoms if g.area > 0.001])
    else:
        _geo_land_poly = _merged
except Exception as _e:
    print(f"Geographic background unavailable: {_e}")

def _draw_geo_background(ax):
    """Fill panel with land/water colors in approximate panel km coords."""
    # Ocean/Bay background
    ax.set_facecolor("#a6cee3")
    if _geo_land_poly is None:
        ax.fill_between([0, LX], [0, 0], [LY, LY], color="#e8e0cc", zorder=0)
        return
    domain_clip = sbox(_GEO_LON_W, _GEO_LAT0, _GEO_LON_E, _GEO_LAT1)
    land_clipped = _geo_land_poly.intersection(domain_clip)

    def _fill_poly(poly):
        if poly.is_empty:
            return
        if poly.geom_type == "Polygon":
            c = np.array(poly.exterior.coords)
            ax.fill(*_geo_to_km(c[:, 1], c[:, 0]),
                    color="#ddd8c0", zorder=0, linewidth=0)
        elif poly.geom_type == "MultiPolygon":
            for p in poly.geoms:
                _fill_poly(p)

    _fill_poly(land_clipped)

# ── dense background scatter on a uniform regular grid ────────────────────
bg_ni, bg_nj = 60, 35
bg_x = np.linspace(0, LX, bg_ni)
bg_y = np.linspace(0, LY, bg_nj)
bgX, bgY = np.meshgrid(bg_x, bg_y)

# ── figure ─────────────────────────────────────────────────────────────────
TITLES  = ["(a)  Random (uniform)", "(b)  Farthest-point",
           "(c)  NCSN-real", "(d)  POD-QR"]
COLORS  = ["#2166ac", "#4dac26", "#d6604d", "#762a83"]
LAYOUTS = [idx_random, idx_farthest, idx_ncsn, idx_podqr]

fig, axes = plt.subplots(2, 2, figsize=(9.8, 7.0), sharex=True, sharey=True)
fig.subplots_adjust(left=0.07, right=0.97, top=0.93, bottom=0.10,
                    wspace=0.06, hspace=0.18)

for ax, idx, title, col in zip(axes.flat, LAYOUTS, TITLES, COLORS):
    # geographic background (land/water)
    _draw_geo_background(ax)
    # domain outline
    ax.add_patch(mpatches.FancyBboxPatch(
        (0, 0), LX, LY, boxstyle="square,pad=0",
        fill=False, edgecolor="#888888", linewidth=0.6, zorder=2))
    # uniform reference grid
    ax.scatter(bgX.ravel(), bgY.ravel(), s=1.5, c="#aaaaaa", zorder=1,
               linewidths=0, rasterized=True)
    # domain box
    for spine in ["bottom", "left", "top", "right"]:
        ax.spines[spine].set_visible(True)
    ax.set_xlim(-1, LX + 1)
    ax.set_ylim(-1, LY + 1)

    # selected stations
    sx, sy = flat_to_km(idx)
    ax.scatter(sx, sy, s=16, c=col, zorder=4, edgecolors="none", alpha=0.88)

    # Hayward Fault
    ax.plot(fault_x, fault_y, color="#8B0000", lw=1.6, zorder=3,
            solid_capstyle="round", label="_")

    ax.set_aspect("equal", adjustable="box")
    ax.set_title(title, fontsize=9, fontweight="bold", pad=4)
    ax.tick_params(labelsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    ax.text(0.97, 0.04, f"n = {len(idx)}", transform=ax.transAxes,
            ha="right", va="bottom", fontsize=8,
            bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="none", alpha=0.85))

# axis labels
for ax in axes[1]:
    ax.set_xlabel("Along-fault  (km)", fontsize=9)
for ax in axes[:, 0]:
    ax.set_ylabel("Across-fault  (km)", fontsize=9)

# legend
fault_p  = mpatches.Patch(color="#8B0000", label="Hayward Fault (schematic)")
grid_p   = mpatches.Patch(color="#cccccc", label=f"Simulation grid ({N_STATIONS:,} stations)")
fig.legend(handles=[grid_p, fault_p], loc="lower center", ncol=2,
           fontsize=8.5, framealpha=0.9, bbox_to_anchor=(0.5, 0.01),
           handlelength=1.4)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
