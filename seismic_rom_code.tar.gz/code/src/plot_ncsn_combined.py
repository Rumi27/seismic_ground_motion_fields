"""Figure: NCSN-real station geometry and global reconstruction comparison.

Three-panel combined figure:
  (a) Station map in simulation km coordinates with land/water background
  (b) Waveform error vs station count — right top
  (c) PGV error vs station count    — right bottom
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import box as sbox
from shapely.ops import unary_union
from pathlib import Path

FONT_SIZE = 11
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": FONT_SIZE,
    "font.weight": "normal",
    "axes.labelsize": FONT_SIZE,
    "axes.titlesize": FONT_SIZE,
    "axes.titleweight": "normal",
    "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "legend.fontsize": 9.5,
})

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results/figures/fig_results_ncsn_combined.pdf"

# ── domain geometry (same as station layouts figure) ─────────────────────────
N_I, N_J = 367, 171
LX, LY   = 73.0, 43.0   # km

_GEO_LAT0, _GEO_LAT1 = 37.38, 38.03    # lat: x=0 → x=LX
_GEO_LON_E, _GEO_LON_W = -121.85, -122.34  # lon: y=0 → y=LY

def _geo_to_km(lats, lons):
    x = (np.asarray(lats) - _GEO_LAT0) / (_GEO_LAT1 - _GEO_LAT0) * LX
    y = (np.asarray(lons) - _GEO_LON_E) / (_GEO_LON_W - _GEO_LON_E) * LY
    return x, y

# ── geographic land polygon (Natural Earth 50 m) ─────────────────────────────
_ne_shp  = ROOT / "data/raw/ne_50m_land/ne_50m_land.shp"
_geo_land_poly = None
try:
    _raw_land = gpd.read_file(str(_ne_shp))
    _clip_box = sbox(-122.55, 37.28, -121.70, 38.12)
    _clipped  = _raw_land[_raw_land.geometry.intersects(_clip_box)].copy()
    _clipped["geometry"] = _clipped.geometry.intersection(_clip_box)
    _merged = unary_union(_clipped.geometry)
    if hasattr(_merged, "geoms"):
        _geo_land_poly = unary_union([g for g in _merged.geoms if g.area > 0.001])
    else:
        _geo_land_poly = _merged
except Exception as _e:
    print(f"Geographic background unavailable: {_e}")


def _draw_geo_background(ax):
    ax.set_facecolor("#a6cee3")          # ocean / SF Bay default
    if _geo_land_poly is None:
        ax.fill_between([0, LX], [0, 0], [LY, LY], color="#e8e0cc", zorder=0)
        return
    domain_clip  = sbox(_GEO_LON_W, _GEO_LAT0, _GEO_LON_E, _GEO_LAT1)
    land_clipped = _geo_land_poly.intersection(domain_clip)

    def _fill_poly(poly):
        if poly.is_empty:
            return
        if poly.geom_type == "Polygon":
            c = np.array(poly.exterior.coords)
            ax.fill(*_geo_to_km(c[:, 1], c[:, 0]),
                    color="#ddd8c0", zorder=0, linewidth=0)
        elif poly.geom_type == "MultiPolygon":
            for p in poly.geoms:
                _fill_poly(p)

    _fill_poly(land_clipped)


# ── full simulation grid (coarse mesh for background dots) ───────────────────
bg_x = np.linspace(0, LX, 60)
bg_y = np.linspace(0, LY, 35)
bgX, bgY = np.meshgrid(bg_x, bg_y)

# ── Hayward Fault schematic (same as station layouts figure) ─────────────────
_cx = LX / 2
fault_x = np.array([_cx - 4, _cx - 1, _cx + 2, _cx + 5])
fault_y = np.array([40, 29, 17, 6])

# ── NCSN station data ─────────────────────────────────────────────────────────
mapping = pd.read_csv(ROOT / "data/processed/ncsn_station_mapping.csv")

# Convert geographic positions to simulation km coordinates
ncsn_x,   ncsn_y   = _geo_to_km(mapping["lat"].values,
                                  mapping["lon"].values)
mapped_x, mapped_y = _geo_to_km(mapping["grid_lat"].values,
                                  mapping["grid_lon"].values)

# ── error curve data ─────────────────────────────────────────────────────────
RANK = 151
ncsn_df = pd.read_csv(ROOT / "results/tables/gappy_pod_mw7_lowfreq_ncsn_geometry.csv")
rnd_df  = pd.read_csv(ROOT / "results/tables/gappy_pod_mw7_lowfreq_random_stations.csv")
far_df  = pd.read_csv(ROOT / "results/tables/gappy_pod_mw7_lowfreq_farthest_stations.csv")

ncsn_r = ncsn_df[ncsn_df["rank"] == RANK].sort_values("n_observed_stations")
rnd_r  = rnd_df [rnd_df ["rank"] == RANK].sort_values("n_observed_stations")
far_r  = far_df [far_df ["rank"] == RANK].sort_values("n_observed_stations")

# ── figure layout ────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(13.5, 8.0))
gs_outer = gridspec.GridSpec(
    1, 2, figure=fig,
    left=0.07, right=0.97, top=0.93, bottom=0.09,
    wspace=0.30, width_ratios=[12, 9],
)
ax_map = fig.add_subplot(gs_outer[0])
gs_right = gridspec.GridSpecFromSubplotSpec(
    2, 1, subplot_spec=gs_outer[1], hspace=0.44,
)
ax_wf  = fig.add_subplot(gs_right[0])
ax_pgv = fig.add_subplot(gs_right[1])

# ── panel (a): station map ───────────────────────────────────────────────────
_draw_geo_background(ax_map)

# domain outline
ax_map.add_patch(mpatches.FancyBboxPatch(
    (0, 0), LX, LY, boxstyle="square,pad=0",
    fill=False, edgecolor="#888888", linewidth=0.6, zorder=2))

# full simulation grid (grey reference dots)
ax_map.scatter(bgX.ravel(), bgY.ravel(), s=1.5, c="#aaaaaa",
               zorder=1, linewidths=0, rasterized=True)

# Hayward Fault schematic
ax_map.plot(fault_x, fault_y, color="#8B0000", lw=1.6, zorder=3,
            solid_capstyle="round")

# NCSN mapped grid points (red)
sc_mapped = ax_map.scatter(
    mapped_x, mapped_y,
    s=22, c="#d62728", alpha=0.80, linewidths=0, zorder=4,
    label="Mapped simulation grid points",
)

# NCSN actual station positions (blue) — clip to visible domain range
in_domain = ((ncsn_x >= -5) & (ncsn_x <= LX + 5) &
             (ncsn_y >= -5) & (ncsn_y <= LY + 5))
sc_ncsn = ax_map.scatter(
    ncsn_x[in_domain], ncsn_y[in_domain],
    s=38, c="#1f77b4", alpha=0.88, linewidths=0.5,
    edgecolors="#0d4d8c", zorder=5,
    label="NCSN station coordinates",
)

ax_map.set_xlim(-1, LX + 1)
ax_map.set_ylim(-1, LY + 1)
ax_map.set_aspect("equal", adjustable="box")
ax_map.set_xlabel("Along-fault  (km)")
ax_map.set_ylabel("Across-fault  (km)")
ax_map.set_title("(a)  NCSN station coordinates mapped to simulation grid")
ax_map.spines["top"].set_visible(False)
ax_map.spines["right"].set_visible(False)

# legend
fault_line = plt.Line2D([0], [0], color="#8B0000", lw=1.6,
                         label="Hayward Fault (schematic)")
grid_patch = mpatches.Patch(color="#aaaaaa", label=f"Simulation grid (62,757 stations)")
ax_map.legend(
    handles=[grid_patch, sc_mapped, sc_ncsn, fault_line],
    fontsize=8.5, loc="upper right", framealpha=0.92,
    handlelength=1.4, borderpad=0.5, labelspacing=0.35,
)

# station count label
ax_map.text(0.97, 0.04, f"n = {in_domain.sum()}",
            transform=ax_map.transAxes, ha="right", va="bottom",
            bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="none", alpha=0.85))

# ── panels (b) and (c): error curves ─────────────────────────────────────────
C_RND  = "#2166ac"
C_FAR  = "#4dac26"
C_NCSN = "#d6604d"
C_IDW  = "#666666"

x_ncsn = ncsn_r["n_observed_stations"].values
x_rnd  = rnd_r ["n_observed_stations"].values
x_far  = far_r ["n_observed_stations"].values

for ax, wf_col, pgv_col, title, ylabel in [
    (ax_wf,
     "mean_rel_error_heldout", "mean_rel_error_heldout",
     "(b)  Waveform error vs observed stations",
     "Relative waveform error"),
    (ax_pgv,
     "mean_pgv_error_heldout", "mean_pgv_error_heldout",
     "(c)  PGV error vs observed stations",
     "Relative PGV error"),
]:
    ax.plot(x_rnd,  rnd_r [wf_col],  "o-",  color=C_RND,  lw=1.9, ms=7,
            label=f"Random  (rank {RANK})")
    ax.plot(x_far,  far_r [wf_col],  "s--", color=C_FAR,  lw=1.9, ms=7,
            label=f"Farthest-point  (rank {RANK})")
    ax.plot(x_ncsn, ncsn_r[wf_col],  "^:",  color=C_NCSN, lw=1.9, ms=7,
            label=f"NCSN-real  (rank {RANK})")
    idw_col = ("mean_idw_baseline_heldout"
               if ax is ax_wf else "mean_idw_baseline_pgv_heldout")
    ax.plot(x_ncsn, ncsn_r[idw_col], "D-.", color=C_IDW, lw=1.4, ms=5,
            label="IDW  (NCSN layout)")
    ax.axhline(1.0, color="#aaaaaa", lw=0.9, ls=":", zorder=0)
    ax.text(x_rnd[0], 1.03, "Mean-field baseline",
            fontsize=8.5, color="#888888", va="bottom")
    ax.set_title(title)
    ax.set_xlabel("Observed stations")
    ax.set_ylabel(ylabel)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

# PGV panel — replot with the correct column
ax_pgv.cla()
ax_pgv.plot(x_rnd,  rnd_r ["mean_pgv_error_heldout"], "o-",  color=C_RND,  lw=1.9, ms=7,
            label=f"Random  (rank {RANK})")
ax_pgv.plot(x_far,  far_r ["mean_pgv_error_heldout"], "s--", color=C_FAR,  lw=1.9, ms=7,
            label=f"Farthest-point  (rank {RANK})")
ax_pgv.plot(x_ncsn, ncsn_r["mean_pgv_error_heldout"], "^:",  color=C_NCSN, lw=1.9, ms=7,
            label=f"NCSN-real  (rank {RANK})")
ax_pgv.plot(x_ncsn, ncsn_r["mean_idw_baseline_pgv_heldout"], "D-.", color=C_IDW,
            lw=1.4, ms=5, label="IDW  (NCSN layout)")
ax_pgv.axhline(1.0, color="#aaaaaa", lw=0.9, ls=":", zorder=0)
ax_pgv.text(x_rnd[0], 1.03, "Mean-field baseline",
            fontsize=8.5, color="#888888", va="bottom")
ax_pgv.set_title("(c)  PGV error vs observed stations")
ax_pgv.set_xlabel("Observed stations")
ax_pgv.set_ylabel("Relative PGV error")
ax_pgv.spines["top"].set_visible(False)
ax_pgv.spines["right"].set_visible(False)

ax_wf.legend(fontsize=9, loc="upper right", framealpha=0.90,
             handlelength=1.8, labelspacing=0.35, borderpad=0.5)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
