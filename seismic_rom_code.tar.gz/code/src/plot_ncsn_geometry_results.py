"""Plot NCSN real-geometry Gappy POD results and station map."""

from __future__ import annotations

import argparse
from pathlib import Path

import h5py
import matplotlib.pyplot as plt
import pandas as pd

from .config import DATA_PROCESSED, DATA_RAW, RESULTS_FIGURES, RESULTS_TABLES


def plot_geometry_comparison(
    random_csv: Path,
    farthest_csv: Path,
    ncsn_csv: Path,
    output_path: Path,
) -> None:
    datasets: list[tuple[pd.DataFrame, str, str]] = []
    for csv_path, label, linestyle in [
        (random_csv, "random", "-"),
        (farthest_csv, "farthest", "--"),
        (ncsn_csv, "NCSN-real-geometry", ":"),
    ]:
        if csv_path.exists():
            datasets.append((pd.read_csv(csv_path), label, linestyle))
    if not datasets:
        raise FileNotFoundError("No input Gappy POD CSV files found")

    ranks = sorted({rank for df, _, _ in datasets for rank in df["rank"].unique()})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8), sharex=True)

    for df, label, linestyle in datasets:
        for rank in ranks:
            sub = df[df["rank"] == rank].sort_values("n_observed_stations")
            if sub.empty:
                continue
            line_label = f"{label}, rank {rank}"
            axes[0].plot(
                sub["n_observed_stations"],
                sub["mean_rel_error_heldout"],
                marker="o",
                linestyle=linestyle,
                label=line_label,
            )
            axes[1].plot(
                sub["n_observed_stations"],
                sub["mean_pgv_error_heldout"],
                marker="o",
                linestyle=linestyle,
                label=line_label,
            )

    ncsn = pd.read_csv(ncsn_csv)
    idw = ncsn.groupby("n_observed_stations", as_index=False)[
        ["mean_idw_baseline_heldout", "mean_idw_baseline_pgv_heldout"]
    ].mean()
    axes[0].plot(
        idw["n_observed_stations"],
        idw["mean_idw_baseline_heldout"],
        color="black",
        marker="s",
        linestyle="-.",
        label="NCSN IDW",
    )
    axes[1].plot(
        idw["n_observed_stations"],
        idw["mean_idw_baseline_pgv_heldout"],
        color="black",
        marker="s",
        linestyle="-.",
        label="NCSN IDW",
    )

    axes[0].set_ylabel("Held-out waveform error")
    axes[1].set_ylabel("Held-out PGV error")
    for ax in axes:
        ax.set_xlabel("Observed stations")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=7)
    fig.suptitle("Gappy POD with random, farthest, and NCSN station geometry")
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path)
    plt.close(fig)
    print(f"Wrote {output_path}")


def plot_station_map(mapping_csv: Path, point_coords_h5: Path, output_path: Path) -> None:
    mapping = pd.read_csv(mapping_csv)
    with h5py.File(point_coords_h5, "r") as handle:
        coords = handle["coordinates"][()]

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(
        coords["lon"],
        coords["lat"],
        s=10,
        c="0.82",
        edgecolors="none",
        label="simulation coordinate points",
    )
    ax.scatter(
        mapping["lon"],
        mapping["lat"],
        s=22,
        c="#1f77b4",
        alpha=0.75,
        label="NCSN stations",
    )
    ax.scatter(
        mapping["grid_lon"],
        mapping["grid_lat"],
        s=12,
        c="#d62728",
        alpha=0.65,
        label="nearest mapped points",
    )
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("NCSN station mapping to simulation coordinates")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path)
    plt.close(fig)
    print(f"Wrote {output_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--random-csv",
        type=Path,
        default=RESULTS_TABLES / "gappy_pod_mw7_lowfreq_random_stations.csv",
    )
    parser.add_argument(
        "--farthest-csv",
        type=Path,
        default=RESULTS_TABLES / "gappy_pod_mw7_lowfreq_farthest_stations.csv",
    )
    parser.add_argument(
        "--ncsn-csv",
        type=Path,
        default=RESULTS_TABLES / "gappy_pod_mw7_lowfreq_ncsn_geometry.csv",
    )
    parser.add_argument(
        "--mapping-csv",
        type=Path,
        default=DATA_PROCESSED / "ncsn_station_mapping.csv",
    )
    parser.add_argument(
        "--point-coords",
        type=Path,
        default=DATA_RAW / "meta" / "point_coordinates.h5",
    )
    parser.add_argument(
        "--comparison-output",
        type=Path,
        default=RESULTS_FIGURES / "gappy_pod_ncsn_geometry_comparison.pdf",
    )
    parser.add_argument(
        "--map-output",
        type=Path,
        default=RESULTS_FIGURES / "ncsn_station_map.pdf",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    plot_geometry_comparison(
        random_csv=args.random_csv,
        farthest_csv=args.farthest_csv,
        ncsn_csv=args.ncsn_csv,
        output_path=args.comparison_output,
    )
    plot_station_map(
        mapping_csv=args.mapping_csv,
        point_coords_h5=args.point_coords,
        output_path=args.map_output,
    )


if __name__ == "__main__":
    main()
