"""Three-panel figure: NCSN λ-sweep analysis.

Panels
------
  (a) L-curve: log‖residual‖ vs log‖coefficient‖ for the full NCSN set and
      the ≤10 km offset subset, with optimal λ marked.
  (b) Per-distance-bin waveform error vs log(λ); horizontal reference at
      mean-field baseline (≈1.0) and random-layout error (0.268).
  (c) Spatial PGV-error map for a representative Mw7 event reconstructed with
      the optimal λ=10⁻⁴ under the full NCSN layout, overlaid with iso-distance
      contours (10, 25, 50 km) from the nearest observed station.

Usage
-----
    python -m src.plot_ncsn_lambda
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.lines as mlines
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy as np
import pandas as pd

from .balanced_pod_analysis import FREQUENCY_BANDS
from .config import DATA_PROCESSED, RESULTS_FIGURES, RESULTS_TABLES
from .gappy_pod_reconstruction import (
    N_COMPONENTS,
    pgv_from_snapshots,
    reconstruct_from_coefficients,
    station_dof_indices,
)
from .plot_spatial_error_map import (
    DEFAULT_STATION_MAPPING,
    LX,
    LY,
    _draw_geo_background,
    load_mapped_station_indices,
    select_stations_ncsn,
    station_coords_km,
)
from .train_lowfreq_opinf import (
    DEFAULT_BAND,
    DEFAULT_DT_SECONDS,
    DEFAULT_EVENT_CLASS,
    assemble_snapshot_matrix,
    compute_pod_basis,
    discover_processed_events,
    load_bandpassed_snapshots,
    split_records,
)

RANK = 151
N_OBSERVED = 128
DEFAULT_LAMBDA_OPT = 1e-4   # optimal for waveform error
DEFAULT_CSV = RESULTS_TABLES / "ncsn_lambda_sweep.csv"
DEFAULT_OUTPUT = RESULTS_FIGURES / "ncsn_lambda_analysis.pdf"

DIST_BIN_COLORS = {
    "0-10km":   "#1f77b4",
    "10-25km":  "#ff7f0e",
    "25-50km":  "#2ca02c",
    ">50km":    "#d62728",
}
LCURVE_COLORS = {"full_144": "#7b2d8b", "offset_le10km_n85": "#c77cff"}


def _load_sweep(csv: Path) -> pd.DataFrame:
    df = pd.read_csv(csv)
    df["log_lambda"] = np.log10(df["lambda"].clip(1e-12))
    return df


def _panel_lcurve(ax, df: pd.DataFrame) -> None:
    for key, color in LCURVE_COLORS.items():
        sub = df[df["ncsn_set"] == key].sort_values("log_lambda")
        label = "full NCSN (128)" if key == "full_144" else "≤10 km subset (85)"
        ax.plot(sub["log_resid_norm"], sub["log_coeff_norm"],
                "o-", color=color, lw=1.6, ms=5, label=label)
        # Mark optimal λ (waveform minimum)
        opt_idx = sub["global_wf"].idxmin()
        opt_row = sub.loc[opt_idx]
        ax.plot(opt_row["log_resid_norm"], opt_row["log_coeff_norm"],
                "*", color=color, ms=12, zorder=5,
                label=f"opt λ = {opt_row['lambda']:.0e}" if key == "full_144" else None)
        ax.annotate(
            f"λ={opt_row['lambda']:.0e}",
            xy=(opt_row["log_resid_norm"], opt_row["log_coeff_norm"]),
            xytext=(8, 4), textcoords="offset points", fontsize=7, color=color,
        )
    ax.set_xlabel(r"$\log_{10}\|\mathbf{V}_\mathrm{obs}\mathbf{c} - \mathbf{x}_\mathrm{obs}\|$",
                  fontsize=9)
    ax.set_ylabel(r"$\log_{10}\|\mathbf{c}\|$", fontsize=9)
    ax.set_title("(a) L-curve", fontsize=9)
    ax.legend(fontsize=7, loc="upper right")
    ax.grid(True, ls=":", lw=0.4, alpha=0.6)
    ax.tick_params(labelsize=8)


def _panel_bin_curves(ax, df: pd.DataFrame) -> None:
    sub = df[df["ncsn_set"] == "full_144"].sort_values("lambda")
    lam = sub["lambda"].values
    log_lam = np.log10(lam.clip(1e-12))

    for col, color in DIST_BIN_COLORS.items():
        wf_col = f"wf_{col}"
        if wf_col not in sub.columns:
            continue
        ax.plot(log_lam, sub[wf_col].values, "o-", color=color,
                lw=1.5, ms=4, label=col)
        # Mark bin optimum
        idx = sub[wf_col].values.argmin()
        ax.plot(log_lam[idx], sub[wf_col].values[idx], "*", color=color, ms=10, zorder=5)

    # Reference lines
    ax.axhline(0.268, color="grey", ls="--", lw=0.9, alpha=0.8,
               label="random layout (n=128)")
    ax.axhline(1.0,   color="black", ls=":",  lw=0.9, alpha=0.5,
               label="mean-field baseline")
    ax.axvline(-4, color="red", ls=":", lw=0.9, alpha=0.6)
    ax.text(-4 + 0.08, 0.05, "opt λ\n=10⁻⁴", fontsize=6.5, va="bottom",
            color="red", alpha=0.9)

    ax.set_xlabel(r"$\log_{10}\lambda$", fontsize=9)
    ax.set_ylabel("Waveform error (held-out)", fontsize=9)
    ax.set_title("(b) Per-bin wf error vs λ (full NCSN set)", fontsize=9)
    ax.legend(fontsize=7, ncol=2, loc="upper right")
    ax.grid(True, ls=":", lw=0.4, alpha=0.6)
    ax.tick_params(labelsize=8)
    ax.set_ylim(bottom=0)


def _panel_spatial(ax, data_root: Path, mapping_csv: Path,
                   lam_opt: float, event_index: int, seed: int,
                   train_fraction: float) -> None:
    band = FREQUENCY_BANDS[DEFAULT_BAND]
    records = discover_processed_events(data_root, event_class=DEFAULT_EVENT_CLASS)
    train_records, val_records = split_records(records, train_fraction=train_fraction, seed=seed)
    rec = val_records[event_index]
    snaps = load_bandpassed_snapshots(rec, band=band)

    train_matrix = assemble_snapshot_matrix(train_records, band=band)
    basis, _ = compute_pod_basis(train_matrix, rank=RANK)
    basis = basis[:, :RANK]
    n_stations = train_matrix.shape[0] // N_COMPONENTS

    ncsn_raw = load_mapped_station_indices(mapping_csv)
    ncsn_valid = ncsn_raw[(ncsn_raw >= 0) & (ncsn_raw < n_stations)]
    obs_idx = select_stations_ncsn(ncsn_valid, N_OBSERVED, n_stations)
    hid_mask = np.ones(n_stations, dtype=bool)
    hid_mask[obs_idx] = False
    hid_idx = np.where(hid_mask)[0]
    hid_dof = station_dof_indices(hid_idx)
    obs_dof = station_dof_indices(obs_idx)

    all_coords = station_coords_km(n_stations)

    # Solve at optimal λ
    v_obs = basis[obs_dof].astype(np.float64)
    x_obs = snaps[obs_dof].astype(np.float64)
    gram = v_obs.T @ v_obs
    c = np.linalg.solve(gram + lam_opt * np.eye(gram.shape[0]), v_obs.T @ x_obs)
    recon = reconstruct_from_coefficients(basis, c.astype(np.float32))

    pgv_ref  = pgv_from_snapshots(snaps,  dt=DEFAULT_DT_SECONDS)
    pgv_pred = pgv_from_snapshots(recon, dt=DEFAULT_DT_SECONDS)

    # Relative PGV error at hidden stations
    rel_err = np.abs(pgv_pred - pgv_ref) / (pgv_ref + 1e-12)
    rel_hid = np.full(n_stations, np.nan)
    rel_hid[hid_idx] = rel_err[hid_idx]

    # Distance from each grid point to nearest observed station
    obs_xy  = all_coords[obs_idx]
    all_xy  = all_coords
    # Compute per-point distance in batches to avoid memory issues
    batch = 5000
    dist_all = np.empty(n_stations)
    for start in range(0, n_stations, batch):
        end = min(start + batch, n_stations)
        diff = all_xy[start:end, None, :] - obs_xy[None, :, :]
        dist_all[start:end] = np.min(np.linalg.norm(diff, axis=2), axis=1)

    # --- Draw ---
    _draw_geo_background(ax)
    ax.set_xlim(-1, LX + 1)
    ax.set_ylim(-1, LY + 1)
    ax.set_aspect("equal", adjustable="box")
    ax.add_patch(mpatches.FancyBboxPatch(
        (0, 0), LX, LY, boxstyle="square,pad=0",
        fill=False, edgecolor="#888", lw=0.5, zorder=2))

    # PGV error scatter
    err_norm = mcolors.PowerNorm(gamma=0.5, vmin=0, vmax=1.5)
    sc = ax.scatter(
        all_coords[:, 0], all_coords[:, 1],
        c=rel_hid, cmap="OrRd", norm=err_norm,
        s=0.8, linewidths=0, rasterized=True, zorder=3,
    )

    # Distance iso-contours: reshape to grid (N_I, N_J)
    from .plot_spatial_error_map import N_I, N_J
    dist_grid = dist_all.reshape(N_I, N_J)
    x_lin = np.linspace(0, LX, N_I)
    y_lin = np.linspace(0, LY, N_J)
    cs = ax.contour(x_lin, y_lin, dist_grid.T,
                    levels=[10, 25, 50],
                    colors=["#1a6e1a", "#e68a00", "#c90000"],
                    linewidths=[0.8, 0.8, 0.8],
                    linestyles=["--", "--", "--"])
    ax.clabel(cs, inline=True, fontsize=6.5, fmt="%g km")

    # Observed stations
    ax.scatter(all_coords[obs_idx, 0], all_coords[obs_idx, 1],
               s=18, marker="^", c="black", linewidths=0.3,
               edgecolors="white", zorder=6, label="NCSN stations")

    # Colorbar
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.05)
    cb = plt.gcf().colorbar(sc, cax=cax)
    cb.set_label("Relative PGV error", fontsize=8)
    cb.ax.tick_params(labelsize=7)

    ax.set_title(f"(c) PGV error at optimal λ = {lam_opt:.0e}", fontsize=9)
    ax.set_xlabel("Along-fault (km)", fontsize=8)
    ax.set_ylabel("Across-fault (km)", fontsize=8)
    ax.tick_params(labelsize=7)
    ax.legend(fontsize=7, loc="upper right", markerscale=0.8)

    mean_hid_err = float(np.nanmean(rel_hid))
    ax.text(0.03, 0.06, f"mean PGV error: {mean_hid_err:.3f}",
            transform=ax.transAxes, fontsize=8, va="bottom",
            bbox=dict(fc="white", alpha=0.8, pad=2, edgecolor="none"))


def plot(
    sweep_csv: Path,
    output_path: Path,
    data_root: Path,
    mapping_csv: Path,
    lam_opt: float,
    event_index: int,
    seed: int,
    train_fraction: float,
) -> None:
    df = _load_sweep(sweep_csv)

    fig = plt.figure(figsize=(14, 4.8))
    gs = fig.add_gridspec(1, 3, wspace=0.38)
    ax_lc  = fig.add_subplot(gs[0])
    ax_bin = fig.add_subplot(gs[1])
    ax_map = fig.add_subplot(gs[2])

    _panel_lcurve(ax_lc, df)
    _panel_bin_curves(ax_bin, df)
    _panel_spatial(ax_map, data_root, mapping_csv, lam_opt,
                   event_index, seed, train_fraction)

    fig.suptitle(
        "NCSN-derived layout: regularisation sensitivity and spatial footprint"
        r" (rank 151, $n=128$, Mw7 low-frequency)",
        fontsize=9,
    )
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    fig.savefig(output_path.with_suffix(".png"), dpi=150, bbox_inches="tight")
    print(f"Saved → {output_path}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--sweep-csv",      type=Path, default=DEFAULT_CSV)
    p.add_argument("--output",         type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--data-root",      type=Path, default=DATA_PROCESSED / "events")
    p.add_argument("--mapping-csv",    type=Path, default=DEFAULT_STATION_MAPPING)
    p.add_argument("--lam-opt",        type=float, default=DEFAULT_LAMBDA_OPT)
    p.add_argument("--event-index",    type=int,   default=0)
    p.add_argument("--seed",           type=int,   default=42)
    p.add_argument("--train-fraction", type=float, default=0.8)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    plot(
        sweep_csv=args.sweep_csv,
        output_path=args.output,
        data_root=args.data_root,
        mapping_csv=args.mapping_csv,
        lam_opt=args.lam_opt,
        event_index=args.event_index,
        seed=args.seed,
        train_fraction=args.train_fraction,
    )


if __name__ == "__main__":
    main()
