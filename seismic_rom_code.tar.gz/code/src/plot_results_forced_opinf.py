"""Figure: Autonomous vs source-forced OpInf comparison (§3.3)."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import pandas as pd
from pathlib import Path

FONT_SIZE = 11
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": FONT_SIZE, "axes.labelsize": FONT_SIZE,
    "axes.titlesize": FONT_SIZE, "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "font.weight": "normal", "axes.titleweight": "normal",
})

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results/figures/fig_results_forced_opinf.pdf"

# ── data ──────────────────────────────────────────────────────────────────
auto  = pd.read_csv(ROOT / "results/tables/lowfreq_opinf_sweep_mw7.csv")
force = pd.read_csv(ROOT / "results/tables/lowfreq_opinf_forced_sweep_mw7.csv")

# Best autonomous per rank (min rollout at λ=1000)
auto_best = (auto[auto["lambda"] == 1000]
             .set_index("rank")[["val_one_step", "val_rollout"]])

# Best forced per rank (λ=1e-6)
force_best = (force[force["lambda"] == 1e-6]
              .set_index("rank")[["val_one_step", "val_rollout"]])

RANKS = [100, 151]

# ── figure: 2-panel grouped bar ────────────────────────────────────────────
fig, (ax_os, ax_ro) = plt.subplots(1, 2, figsize=(9.5, 4.0))
fig.subplots_adjust(left=0.08, right=0.97, top=0.88, bottom=0.14, wspace=0.32)

x     = np.arange(len(RANKS))
w     = 0.32
c_aut = "#4393c3"   # blue for autonomous
c_frc = "#d6604d"   # red for source-forced

for ax, metric, title, ylabel, ymax in [
    (ax_os, "val_one_step", "(a)  One-step error", "Relative one-step error", 0.42),
    (ax_ro, "val_rollout",  "(b)  Rollout error",  "Relative rollout error",  1.55),
]:
    aut_vals = [auto_best.loc[r, metric]  for r in RANKS]
    frc_vals = [force_best.loc[r, metric] for r in RANKS]

    bars_a = ax.bar(x - w/2, aut_vals, w, color=c_aut, alpha=0.88, zorder=3,
                    label="Autonomous")
    bars_f = ax.bar(x + w/2, frc_vals, w, color=c_frc, alpha=0.88, zorder=3,
                    label="Source-forced")

    # percentage reduction annotations
    for xi, av, fv in zip(x, aut_vals, frc_vals):
        pct = (av - fv) / av * 100
        ax.annotate(f"−{pct:.0f}%",
                    xy=(xi, max(av, fv) + ymax * 0.025),
                    ha="center", va="bottom", fontsize=9, color="#333333")

    # baseline at 1.0 for rollout panel
    if metric == "val_rollout":
        ax.axhline(1.0, color="#888888", lw=0.9, ls="--", zorder=1)
        ax.text(x[-1] + 0.55, 1.01, "Mean-field\nbaseline",
                fontsize=8, color="#666666", va="bottom", ha="right")

    ax.set_xticks(x)
    ax.set_xticklabels([f"Rank {r}" for r in RANKS])
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(0, ymax)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(fontsize=9, framealpha=0.88, loc="upper left",
              handlelength=1.2, borderpad=0.4)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
