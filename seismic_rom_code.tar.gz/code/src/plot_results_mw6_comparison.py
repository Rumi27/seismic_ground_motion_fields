"""Figure: Mw6 vs Mw7 reconstruction comparison (§3.10)."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

FONT_SIZE = 11
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": FONT_SIZE, "axes.labelsize": FONT_SIZE,
    "axes.titlesize": FONT_SIZE, "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "font.weight": "normal", "axes.titleweight": "normal",
})

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results/figures/fig_results_mw6_comparison.pdf"

# ── Mw6 data ───────────────────────────────────────────────────────────────
mw6 = pd.read_csv(ROOT / "results/tables/gappy_pod_mw6_lowfreq_random_multiseed_rank150_128.csv")
mw6 = mw6[mw6["station_selection"] == "random"]

# ── Mw7 data — use paper-reported IDW summary (optimised λ, 10 seeds) ─────
mw7_summ = pd.read_csv(ROOT / "results/tables/gappy_pod_mw7_lowfreq_random_multiseed_idw_128_summary.csv")
mw7_row  = mw7_summ[mw7_summ["method"] == "gappy POD rank 151"].iloc[0]

def stats(df, col):
    return df[col].mean(), df[col].std()

mw6_wf_m,  mw6_wf_s  = stats(mw6, "mean_rel_error_heldout")
mw6_pgv_m, mw6_pgv_s = stats(mw6, "mean_pgv_error_heldout")
mw6_base   = mw6["mean_baseline_heldout"].mean()

mw7_wf_m,  mw7_wf_s  = float(mw7_row["waveform_mean"]), float(mw7_row["waveform_std"])
mw7_pgv_m, mw7_pgv_s = float(mw7_row["pgv_mean"]),      float(mw7_row["pgv_std"])
mw7_base   = 0.989   # mean-field baseline from paper

# ── figure ─────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(9.0, 4.0))
fig.subplots_adjust(left=0.09, right=0.97, top=0.88, bottom=0.14, wspace=0.30)

x = np.array([0, 1])
w = 0.32
C_MW6 = "#4dac26"
C_MW7 = "#d6604d"

for ax, (mw6_m, mw6_s, mw7_m, mw7_s, mw6_b, mw7_b), title, ylabel, ylim in [
    (axes[0],
     (mw6_wf_m, mw6_wf_s, mw7_wf_m, mw7_wf_s, mw6_base, mw7_base),
     "(a)  Waveform error", "Relative waveform error", (0, 1.15)),
    (axes[1],
     (mw6_pgv_m, mw6_pgv_s, mw7_pgv_m, mw7_pgv_s, 1.0, 1.0),
     "(b)  PGV error", "Relative PGV error", (0, 0.35)),
]:
    # Gappy POD bars
    ax.bar([0 - w/2], [mw6_m], w, color=C_MW6, alpha=0.88, zorder=3,
           label="Mw6 (rank 150)")
    ax.bar([0 + w/2], [mw7_m], w, color=C_MW7, alpha=0.88, zorder=3,
           label="Mw7 (rank 151)")
    ax.errorbar([0 - w/2], [mw6_m], yerr=[mw6_s], fmt="none", color="#333333",
                capsize=4, lw=1.2, zorder=4)
    ax.errorbar([0 + w/2], [mw7_m], yerr=[mw7_s], fmt="none", color="#333333",
                capsize=4, lw=1.2, zorder=4)

    # Mean-field baseline markers
    ax.plot([0 - w], [mw6_b], "_", ms=18, color=C_MW6, mew=2.0, zorder=5)
    ax.plot([0 + w], [mw7_b], "_", ms=18, color=C_MW7, mew=2.0, zorder=5)
    ax.annotate("mean-field\nbaseline ≈ 1",
                xy=(0 + w, mw7_b), xytext=(0 + w + 0.1, mw7_b + ylim[1]*0.05),
                fontsize=8, color="#555555", ha="left",
                arrowprops=dict(arrowstyle="-", color="#aaaaaa", lw=0.7))

    # reduction factor
    fac6 = mw6_b / mw6_m
    fac7 = mw7_b / mw7_m
    ax.text(0 - w/2, mw6_m + ylim[1]*0.02, f"÷{fac6:.1f}",
            ha="center", va="bottom", fontsize=9, color=C_MW6)
    ax.text(0 + w/2, mw7_m + ylim[1]*0.02, f"÷{fac7:.1f}",
            ha="center", va="bottom", fontsize=9, color=C_MW7)

    ax.set_xticks([0])
    ax.set_xticklabels(["Random layout\n128 stations"])
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(ylim)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(fontsize=9, loc="upper right", framealpha=0.88,
              handlelength=1.2, borderpad=0.4)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
