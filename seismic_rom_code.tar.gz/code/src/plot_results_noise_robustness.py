"""Figure: Noise robustness of gappy POD (§3.7)."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

FONT_SIZE = 11
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": FONT_SIZE, "axes.labelsize": FONT_SIZE,
    "axes.titlesize": FONT_SIZE, "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "font.weight": "normal", "axes.titleweight": "normal",
})

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results/figures/fig_results_noise_robustness.pdf"

df = pd.read_csv(ROOT / "results/tables/noise_robustness_gappy_pod_mw7.csv")
df = df[df["rank"] == 151].copy()

DELTA_LABELS = ["0\n(clean)", "0.1%\n(SNR 1000)", "1%\n(SNR 100)", "5%\n(SNR 20)"]
DELTAS = [0.0, 0.001, 0.01, 0.05]

LAYOUT_STYLE = {
    "random": {"fixed": ("#2166ac", "-",  "o", "Random, fixed $\\lambda$"),
               "dp":    ("#2166ac", "--", "s", "Random, $\\lambda_\\mathrm{dp}$")},
    "ncsn":   {"fixed": ("#d6604d", "-",  "o", "NCSN, fixed $\\lambda$"),
               "dp":    ("#d6604d", "--", "s", "NCSN, $\\lambda_\\mathrm{dp}$")},
}

def get_vals(layout, metric_col):
    sub = df[df["layout"] == layout].set_index("delta")
    return [sub.loc[d, metric_col] if d in sub.index else np.nan for d in DELTAS]

x = np.arange(len(DELTAS))

fig, (ax_wf, ax_pgv) = plt.subplots(1, 2, figsize=(10.5, 4.2))
fig.subplots_adjust(left=0.08, right=0.97, top=0.88, bottom=0.14, wspace=0.30)

for ax, wf_col, pgv_col, title, ylabel, ylim in [
    (ax_wf, "mean_wf_fixed",  "mean_wf_dp",
     "(a)  Waveform error vs noise level", "Relative waveform error", (0, 2.0)),
    (ax_pgv, "mean_pgv_fixed", "mean_pgv_dp",
     "(b)  PGV error vs noise level", "Relative PGV error", (0, 5.5)),
]:
    for layout in ["random", "ncsn"]:
        sty = LAYOUT_STYLE[layout]
        # fixed lambda
        col_f, ls_f, mk_f, lbl_f = sty["fixed"]
        vals_f = get_vals(layout, wf_col if "wf" in wf_col else pgv_col)
        ax.plot(x, vals_f, color=col_f, ls=ls_f, marker=mk_f, ms=7, lw=1.8,
                label=lbl_f, zorder=3)
        # discrepancy principle lambda
        col_d, ls_d, mk_d, lbl_d = sty["dp"]
        dp_col = wf_col.replace("fixed", "dp") if "fixed" in wf_col else pgv_col.replace("fixed", "dp")
        vals_d = get_vals(layout, dp_col)
        ax.plot(x, vals_d, color=col_d, ls=ls_d, marker=mk_d, ms=7, lw=1.8,
                label=lbl_d, zorder=3, alpha=0.75)

    # mean-field baseline
    ax.axhline(1.0, color="#888888", lw=0.9, ls=":", zorder=1)
    ax.text(x[-1] + 0.05, 1.01, "Mean-field", fontsize=8, color="#888888", va="bottom")

    # annotate catastrophic failure for NCSN PGV at 5% if applicable
    if "pgv" in (wf_col + pgv_col).lower() and ylim[1] > 4:
        ncsn_pgv5 = df[(df["layout"] == "ncsn") & (df["delta"] == 0.05)]["mean_pgv_fixed"].values
        if len(ncsn_pgv5) and ncsn_pgv5[0] > ylim[1] * 0.85:
            ax.annotate(f"≈{ncsn_pgv5[0]:.1f}",
                        xy=(x[-1], ylim[1] - 0.2),
                        fontsize=9, color="#d6604d", ha="center", va="top")

    ax.set_xticks(x)
    ax.set_xticklabels(DELTA_LABELS)
    ax.set_xlabel("Noise level $\\delta$  (fraction of $\\sigma_\\mathrm{ev}$)")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(ylim)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

ax_wf.legend(fontsize=9, loc="upper left", framealpha=0.88,
             handlelength=1.8, borderpad=0.4)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
