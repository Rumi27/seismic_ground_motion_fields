"""Figure: Windowed forcing and piecewise operators (§3.4)."""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import pandas as pd
from pathlib import Path

FONT_SIZE = 11
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
    "font.size": FONT_SIZE, "axes.labelsize": FONT_SIZE,
    "axes.titlesize": FONT_SIZE, "xtick.labelsize": FONT_SIZE,
    "ytick.labelsize": FONT_SIZE,
    "font.weight": "normal", "axes.titleweight": "normal",
})

ROOT = Path(__file__).parents[1]
OUT  = ROOT / "results/figures/fig_results_windowed_opinf.pdf"

df = pd.read_csv(ROOT / "results/tables/windowed_forced_opinf_sweep_mw7.csv")
df = df[df["rank"] == 151].copy()

# Build ordered config labels and group IDs
def make_label(row):
    if row["window_type"] == "static":
        return "Static\n(baseline)"
    wt = "Exp" if row["window_type"] == "exp" else "Hann"
    tau = int(row["tau"])
    if row["k_switch"] < 0:
        return f"{wt}\nτ={tau}"
    return f"{wt} τ={tau}\n$k_{{sw}}$={int(row['k_switch'])}"

df["label"] = df.apply(make_label, axis=1)

# Group: 0=static, 1=Fix1, 2=Fix1+2
def make_group(row):
    if row["window_type"] == "static":
        return 0
    elif row["k_switch"] < 0:
        return 1
    else:
        return 2
df["group"] = df.apply(make_group, axis=1)
df = df.sort_values(["group", "tau", "k_switch"]).reset_index(drop=True)

COLORS = {0: "#888888", 1: "#4393c3", 2: "#d6604d"}
LABELS = {0: "Baseline (static forcing)", 1: "Fix 1: windowed forcing",
          2: "Fix 1+2: windowed + piecewise"}

# ── figure ─────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 4.2))
fig.subplots_adjust(left=0.09, right=0.97, top=0.88, bottom=0.20)

x = np.arange(len(df))
bar_colors = [COLORS[g] for g in df["group"]]

# full rollout bars
bars = ax.bar(x, df["val_rollout"], 0.55, color=bar_colors, alpha=0.85, zorder=3)

# late rollout overlay (hatched)
ax.bar(x, df["val_late_rollout"], 0.55, color=bar_colors, alpha=0.35,
       hatch="///", edgecolor="white", linewidth=0.5, zorder=2)

# mean-field baseline
ax.axhline(1.0, color="#555555", lw=1.0, ls="--", zorder=1)
ax.text(len(df) - 0.4, 1.02, "Mean-field baseline", fontsize=8.5,
        color="#555555", ha="right", va="bottom")

# spectral radius annotations for Fix1+2 configs
for i, row in df[df["group"] == 2].iterrows():
    xi = df.index.get_loc(i)
    rho_e = row["rho_A_early"]
    rho_l = row["rho_A_late"]
    ax.text(xi, min(row["val_rollout"] + 0.25, 7.8),
            f"ρ_e={rho_e:.3f}\nρ_l={rho_l:.3f}",
            ha="center", va="bottom", fontsize=7.5, color="#8B0000")

ax.set_xticks(x)
ax.set_xticklabels(df["label"], fontsize=9, rotation=0, ha="center")
ax.set_ylabel("Relative rollout error")
ax.set_title("(a)  Windowed forcing and piecewise operator rollout errors"
             " — rank 151, Mw7 low-freq")
ax.set_ylim(0, 8.5)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

# group separators
group_bounds = []
prev = df["group"].iloc[0]
for i, g in enumerate(df["group"]):
    if g != prev:
        ax.axvline(i - 0.5, color="#cccccc", lw=1.0, ls="-", zorder=0)
        group_bounds.append(i - 0.5)
        prev = g

# legend
handles = [mpatches.Patch(color=COLORS[g], alpha=0.85, label=LABELS[g]) for g in sorted(COLORS)]
handles += [mpatches.Patch(facecolor="#aaaaaa", hatch="///", edgecolor="white",
                            label="Late rollout ($k \\geq 94$)")]
ax.legend(handles=handles, fontsize=9, loc="upper left", framealpha=0.88,
          handlelength=1.4, borderpad=0.4, ncol=2)

fig.savefig(OUT, bbox_inches="tight", dpi=300)
print(f"Saved → {OUT}")
