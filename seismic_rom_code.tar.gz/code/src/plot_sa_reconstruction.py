"""Long-period spectral acceleration Sa(T) reconstruction error.

Computes pseudo-spectral acceleration Sa(T) from reconstructed and reference
low-frequency displacement waveforms at T = 5 s and T = 7.5 s for a
representative held-out Mw7 event.  Produces a four-panel spatial map for
T = 5 s and prints mean relative errors across layouts and periods.

The SDOF response is computed in the frequency domain to avoid numerical
differentiation:  X_rel(ω) = ω²·U_g(ω) / (ω₀² − ω² + 2iξω₀ω),
and pseudo-Sa = ω₀² · max|x_rel(t)|.  Only horizontal components (X, Y) are
used; the geometric mean approximates RotD50.

Usage
-----
    python -m src.plot_sa_reconstruction
    python -m src.plot_sa_reconstruction --rank 151 --n-observed 128
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy as np

from .balanced_pod_analysis import DEFAULT_DT_SECONDS, FREQUENCY_BANDS
from .config import DATA_PROCESSED, RESULTS_FIGURES
from .gappy_pod_reconstruction import (
    N_COMPONENTS,
    reconstruct_from_coefficients,
    solve_gappy_coefficients,
)
from .train_lowfreq_opinf import (
    DEFAULT_BAND,
    DEFAULT_EVENT_CLASS,
    assemble_snapshot_matrix,
    compute_pod_basis,
    discover_processed_events,
    load_bandpassed_snapshots,
    split_records,
)
from .plot_spatial_error_map import (
    DEFAULT_STATION_MAPPING,
    LX,
    LY,
    _draw_geo_background,
    load_mapped_station_indices,
    pod_qr_station_order,
    select_stations_ncsn,
    select_stations_pod_qr,
    select_stations_random,
    station_coords_km,
)

# Periods reported in text; PLOT_PERIOD used for spatial figure
# T=4 s is at the passband edge (f=0.25 Hz); T=5 and 7.5 s are well inside.
# T=2–3 s (f=0.5–0.33 Hz) are outside the 0.02–0.25 Hz passband.
PERIODS = [4.0, 5.0, 7.5]
PLOT_PERIOD = 5.0


def compute_pgd(snapshots: np.ndarray) -> np.ndarray:
    """Peak ground displacement: max horizontal displacement magnitude per station.

    Returns (n_stations,) array.  Works on band-passed displacement snapshots,
    so it reflects only energy within the 0.02–0.25 Hz passband.
    """
    n_dof = snapshots.shape[0]
    n_stations = n_dof // N_COMPONENTS
    u = snapshots.reshape(N_COMPONENTS, n_stations, -1)
    horiz = np.sqrt(u[0] ** 2 + u[1] ** 2)
    return np.max(horiz, axis=-1)


def compute_sa(
    snapshots: np.ndarray,
    period: float,
    dt: float,
    xi: float = 0.05,
) -> np.ndarray:
    """Pseudo-Sa from band-passed displacement snapshots (freq-domain SDOF).

    snapshots : (N_COMPONENTS * n_stations, n_time)
    Returns   : (n_stations,) geometric mean of horizontal components.
    """
    n_dof, n_time = snapshots.shape
    n_stations = n_dof // N_COMPONENTS
    u = snapshots.reshape(N_COMPONENTS, n_stations, n_time)

    omega0 = 2.0 * np.pi / period
    omega = 2.0 * np.pi * np.fft.rfftfreq(n_time, d=dt)

    # Transfer function: X_rel = ω²·U_g / (ω₀² − ω² + 2iξω₀ω)
    H = omega**2 / (omega0**2 - omega**2 + 2j * xi * omega0 * omega)

    sa_horiz = []
    for ic in range(2):  # components 0=X, 1=Y (horizontal)
        U_g = np.fft.rfft(u[ic], axis=-1)
        x_rel = np.fft.irfft(H[np.newaxis, :] * U_g, n=n_time, axis=-1)
        sa_horiz.append(omega0**2 * np.max(np.abs(x_rel), axis=-1))

    return np.sqrt(sa_horiz[0] * sa_horiz[1])


def run(
    data_root: Path,
    band_name: str,
    rank: int,
    n_observed: int,
    seed: int,
    event_index: int,
    train_fraction: float,
    regularization: float,
    station_mapping_csv: Path,
    output_path: Path,
) -> None:
    band = FREQUENCY_BANDS[band_name]
    records = discover_processed_events(data_root, event_class=DEFAULT_EVENT_CLASS)
    train_records, val_records = split_records(
        records, train_fraction=train_fraction, seed=seed
    )
    if event_index >= len(val_records):
        raise ValueError(f"event_index {event_index} out of range "
                         f"({len(val_records)} val events)")
    target_record = val_records[event_index]
    print(f"Event: {target_record.path.name}")

    train_matrix = assemble_snapshot_matrix(train_records, band=band)
    basis, _ = compute_pod_basis(train_matrix, rank=rank)
    n_stations = train_matrix.shape[0] // N_COMPONENTS

    snapshots = load_bandpassed_snapshots(target_record, band=band)
    coords = station_coords_km(n_stations)

    ncsn_indices = load_mapped_station_indices(station_mapping_csv)
    layouts: dict[str, np.ndarray] = {
        "random": select_stations_random(
            n_stations, n_observed, np.random.default_rng(seed)
        ),
        "POD-QR": select_stations_pod_qr(
            pod_qr_station_order(basis, n_stations), n_observed, n_stations
        ),
        "NCSN-derived": select_stations_ncsn(ncsn_indices, n_observed, n_stations),
    }

    # Reference Sa at each period and PGD
    sa_ref: dict[float, np.ndarray] = {
        T: compute_sa(snapshots, T, DEFAULT_DT_SECONDS) for T in PERIODS
    }
    pgd_ref = compute_pgd(snapshots)

    # Reconstruct and compute Sa / PGD errors
    results: dict[str, tuple[np.ndarray, dict]] = {}
    for layout_name, obs_stations in layouts.items():
        coefficients, _ = solve_gappy_coefficients(
            basis, snapshots, obs_stations, regularization
        )
        recon = reconstruct_from_coefficients(basis, coefficients)
        sa_errs: dict[float, tuple[np.ndarray, float]] = {}
        for T in PERIODS:
            sa_r = compute_sa(recon, T, DEFAULT_DT_SECONDS)
            rel = np.abs(sa_r - sa_ref[T]) / (sa_ref[T] + 1e-12)
            rel_hidden = rel.copy()
            rel_hidden[obs_stations] = np.nan
            mean_hidden = float(np.nanmean(rel_hidden))
            sa_errs[T] = (rel_hidden, mean_hidden)
            print(f"  {layout_name:<16s}  T={T:.1f}s  "
                  f"mean Sa rel-err (hidden) = {mean_hidden:.3f}")
        # PGD
        pgd_r = compute_pgd(recon)
        pgd_rel = np.abs(pgd_r - pgd_ref) / (pgd_ref + 1e-12)
        pgd_rel_hid = pgd_rel.copy()
        pgd_rel_hid[obs_stations] = np.nan
        mean_pgd = float(np.nanmean(pgd_rel_hid))
        sa_errs["pgd"] = (pgd_rel_hid, mean_pgd)
        print(f"  {layout_name:<16s}  PGD   mean rel-err (hidden) = {mean_pgd:.3f}")
        results[layout_name] = (obs_stations, sa_errs)

    # Shared colour scale for error panels (96th percentile)
    pooled = np.concatenate([
        results[n][1][PLOT_PERIOD][0][~np.isnan(results[n][1][PLOT_PERIOD][0])]
        for n in layouts
    ])
    vmax_err = float(np.clip(np.nanpercentile(pooled, 96), 0.35, 1.25))
    err_norm = mcolors.PowerNorm(gamma=0.55, vmin=0.0, vmax=vmax_err)
    print(f"Sa({PLOT_PERIOD}s) error colour scale: vmax={vmax_err:.3f}")

    # ── Figure ─────────────────────────────────────────────────────────────────
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
        "font.size": 11,
        "axes.labelsize": 11,
        "axes.titlesize": 11,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "font.weight": "normal",
        "axes.titleweight": "normal",
    })

    fig, axes = plt.subplots(2, 2, figsize=(11, 6.4))
    fig.subplots_adjust(left=0.08, right=0.97, top=0.92, bottom=0.10,
                        wspace=0.42, hspace=0.38)
    cmap_ref = plt.get_cmap("YlOrRd").copy()
    cmap_err = plt.get_cmap("OrRd").copy()
    cmap_err.set_bad(color="#d8d8d8")
    scatter_kw = dict(s=1.0, linewidths=0, rasterized=True)
    obs_kw = dict(s=20, marker="^", c="k", linewidths=0.3,
                  edgecolors="white", zorder=5, label="Observed stations")

    panel_titles = [
        f"(a) Reference $S_a$(T\\,=\\,{PLOT_PERIOD:.0f}\\,s)",
        f"(b) Random layout  —  $S_a$ error",
        f"(c) POD-QR layout  —  $S_a$ error",
        f"(d) NCSN-derived  —  $S_a$ error",
    ]

    def _style(ax: plt.Axes, title: str) -> None:
        _draw_geo_background(ax)
        ax.set_xlim(-1, LX + 1)
        ax.set_ylim(-1, LY + 1)
        ax.set_aspect("equal", adjustable="box")
        ax.add_patch(mpatches.FancyBboxPatch(
            (0, 0), LX, LY, boxstyle="square,pad=0",
            fill=False, edgecolor="#888888", linewidth=0.5, zorder=2))
        ax.set_title(title, pad=4)
        ax.set_xlabel("Along-fault  (km)", labelpad=2)
        ax.set_ylabel("Across-fault  (km)", labelpad=2)

    def _cbar(ax: plt.Axes, sc, label: str) -> None:
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.06)
        cb = fig.colorbar(sc, cax=cax)
        cb.set_label(label, fontsize=10)
        cb.ax.tick_params(labelsize=8.5)

    # Reference panel
    ax0 = axes[0, 0]
    _style(ax0, panel_titles[0])
    vmax_ref = float(np.percentile(sa_ref[PLOT_PERIOD], 99))
    sc = ax0.scatter(coords[:, 0], coords[:, 1],
                     c=sa_ref[PLOT_PERIOD],
                     cmap=cmap_ref, vmin=0, vmax=vmax_ref,
                     zorder=3, **scatter_kw)
    _cbar(ax0, sc, "$S_a$ (normalised)")

    # Error panels
    for ax, (layout_name, (obs_stations, sa_errs)), title in zip(
        [axes[0, 1], axes[1, 0], axes[1, 1]],
        results.items(),
        panel_titles[1:],
    ):
        rel_hidden, mean_err = sa_errs[PLOT_PERIOD]
        _style(ax, title)
        sc = ax.scatter(coords[:, 0], coords[:, 1],
                        c=rel_hidden, cmap=cmap_err, norm=err_norm,
                        zorder=3, **scatter_kw)
        _cbar(ax, sc, "Relative $S_a$ error")
        ax.scatter(coords[obs_stations, 0], coords[obs_stations, 1], **obs_kw)
        ax.text(0.03, 0.91, f"mean error: {mean_err:.3f}",
                transform=ax.transAxes, fontsize=9, va="top", ha="left",
                bbox=dict(fc="white", alpha=0.75, pad=2, edgecolor="none"))

    axes[1, 1].legend(fontsize=9, loc="lower right",
                      framealpha=0.85, markerscale=1.2, handletextpad=0.4)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {output_path}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-root", type=Path, default=DATA_PROCESSED / "events")
    p.add_argument("--band", choices=sorted(FREQUENCY_BANDS), default=DEFAULT_BAND)
    p.add_argument("--rank", type=int, default=151)
    p.add_argument("--n-observed", type=int, default=128)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--event-index", type=int, default=0)
    p.add_argument("--train-fraction", type=float, default=0.8)
    p.add_argument("--regularization", type=float, default=1e-8)
    p.add_argument("--station-mapping-csv", type=Path,
                   default=DEFAULT_STATION_MAPPING)
    p.add_argument("--output", type=Path,
                   default=RESULTS_FIGURES / "fig_sa_reconstruction.pdf")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    run(
        data_root=args.data_root,
        band_name=args.band,
        rank=args.rank,
        n_observed=args.n_observed,
        seed=args.seed,
        event_index=args.event_index,
        train_fraction=args.train_fraction,
        regularization=args.regularization,
        station_mapping_csv=args.station_mapping_csv,
        output_path=args.output,
    )


if __name__ == "__main__":
    main()
