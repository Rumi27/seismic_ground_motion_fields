"""Spatial PGV error map for a representative Mw7 held-out event.

Produces a four-panel figure comparing the reference PGV field against
gappy POD reconstruction error under random, POD-QR, and NCSN-real layouts
at rank 151 and 128 stations.

Usage
-----
    python -m src.plot_spatial_error_map
    python -m src.plot_spatial_error_map --rank 151 --n-observed 128 --seed 42
    python -m src.plot_spatial_error_map --event-index 0  # first held-out
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy as np
import pandas as pd
from scipy.linalg import qr
import geopandas as gpd
from shapely.geometry import box as sbox
from shapely.ops import unary_union

from .balanced_pod_analysis import FREQUENCY_BANDS
from .config import DATA_PROCESSED, DATA_RAW, RESULTS_FIGURES
from .gappy_pod_reconstruction import (
    N_COMPONENTS,
    pgv_from_snapshots,
    reconstruct_from_coefficients,
    solve_gappy_coefficients,
)
from .train_lowfreq_opinf import (
    DEFAULT_BAND,
    DEFAULT_DT_SECONDS,
    DEFAULT_EVENT_CLASS,
    assemble_snapshot_matrix,
    compute_pod_basis,
    discover_processed_events,
    load_bandpassed_snapshots,
    split_records,
)

DEFAULT_STATION_MAPPING = DATA_PROCESSED / "ncsn_station_mapping.csv"

# Simulation surface grid (matches preprocess / layout figures)
N_I, N_J = 367, 171
LX, LY = 73.0, 43.0

# Geographic domain extents (same as station layout figure)
_GEO_LAT0, _GEO_LAT1 = 37.38, 38.03
_GEO_LON_E, _GEO_LON_W = -121.85, -122.34

_ne_shp = DATA_RAW / "ne_50m_land" / "ne_50m_land.shp"
_geo_land_poly = None
try:
    _raw_land = gpd.read_file(str(_ne_shp))
    _clip_box = sbox(-122.55, 37.28, -121.70, 38.12)
    _clipped = _raw_land[_raw_land.geometry.intersects(_clip_box)].copy()
    _clipped["geometry"] = _clipped.geometry.intersection(_clip_box)
    _merged = unary_union(_clipped.geometry)
    if hasattr(_merged, "geoms"):
        _geo_land_poly = unary_union([g for g in _merged.geoms if g.area > 0.001])
    else:
        _geo_land_poly = _merged
except Exception as _e:
    print(f"Geographic background unavailable: {_e}")


def _geo_to_km(lats, lons):
    x = (np.asarray(lats) - _GEO_LAT0) / (_GEO_LAT1 - _GEO_LAT0) * LX
    y = (np.asarray(lons) - _GEO_LON_E) / (_GEO_LON_W - _GEO_LON_E) * LY
    return x, y


def _draw_geo_background(ax: "plt.Axes") -> None:
    ax.set_facecolor("#a6cee3")
    if _geo_land_poly is None:
        ax.fill_between([0, LX], [0, 0], [LY, LY], color="#e8e0cc", zorder=0)
        return
    domain_clip = sbox(_GEO_LON_W, _GEO_LAT0, _GEO_LON_E, _GEO_LAT1)
    land_clipped = _geo_land_poly.intersection(domain_clip)

    def _fill_poly(poly):
        if poly.is_empty:
            return
        if poly.geom_type == "Polygon":
            c = np.array(poly.exterior.coords)
            ax.fill(*_geo_to_km(c[:, 1], c[:, 0]), color="#ddd8c0", zorder=0, linewidth=0)
        elif poly.geom_type == "MultiPolygon":
            for p in poly.geoms:
                _fill_poly(p)

    _fill_poly(land_clipped)


def station_coords_km(n_stations: int) -> np.ndarray:
    """(n_stations, 2) along-fault and across-fault coordinates in km."""
    if n_stations != N_I * N_J:
        raise ValueError(f"Expected {N_I * N_J} stations, got {n_stations}")
    i0 = np.arange(n_stations) // N_J
    j0 = np.arange(n_stations) % N_J
    x = i0 / (N_I - 1) * LX
    y = j0 / (N_J - 1) * LY
    return np.stack([x, y], axis=1)


def select_stations_random(
    n_stations: int, n_observed: int, rng: np.random.Generator
) -> np.ndarray:
    return np.sort(rng.choice(n_stations, size=n_observed, replace=False))


def select_stations_farthest(
    coords: np.ndarray, n_observed: int, rng: np.random.Generator
) -> np.ndarray:
    n_stations = coords.shape[0]
    selected = [int(rng.integers(n_stations))]
    dists = np.full(n_stations, np.inf)
    while len(selected) < n_observed:
        last = coords[selected[-1]]
        d = np.linalg.norm(coords - last, axis=1)
        dists = np.minimum(dists, d)
        dists[selected] = -1
        selected.append(int(np.argmax(dists)))
    return np.sort(np.asarray(selected, dtype=np.int64))


def load_mapped_station_indices(mapping_csv: Path) -> np.ndarray:
    df = pd.read_csv(mapping_csv)
    return (
        df["nearest_station_index"]
        .dropna()
        .astype(np.int64)
        .drop_duplicates()
        .to_numpy()
    )


def select_stations_ncsn(
    mapped_indices: np.ndarray, n_observed: int, n_stations: int
) -> np.ndarray:
    valid = mapped_indices[(mapped_indices >= 0) & (mapped_indices < n_stations)]
    if valid.size < n_observed:
        raise ValueError(
            f"Only {valid.size} mapped NCSN stations available; need {n_observed}"
        )
    return np.sort(valid[:n_observed])


def pod_qr_station_order(basis: np.ndarray, n_stations: int, n_modes: int = 50) -> np.ndarray:
    v = basis[:, :n_modes].astype(np.float64)
    blk = v.reshape(N_COMPONENTS, n_stations, n_modes)
    qmat = blk.transpose(2, 0, 1).reshape(n_modes * N_COMPONENTS, n_stations)
    _, _, piv = qr(qmat, mode="economic", pivoting=True, check_finite=False)
    return piv.astype(np.int64)


def select_stations_pod_qr(
    station_order: np.ndarray, n_observed: int, n_stations: int
) -> np.ndarray:
    if station_order.size < n_observed:
        raise ValueError("POD-QR station order shorter than n_observed")
    return np.sort(station_order[:n_observed])


def _reconstruct_layout(
    basis: np.ndarray,
    snapshots: np.ndarray,
    observed_stations: np.ndarray,
    regularization: float,
    dt: float,
) -> tuple[np.ndarray, np.ndarray]:
    coefficients, hidden_stations = solve_gappy_coefficients(
        basis, snapshots, observed_stations, regularization
    )
    full_recon = reconstruct_from_coefficients(basis, coefficients)
    pgv_recon = pgv_from_snapshots(full_recon, dt=dt)
    return pgv_recon, hidden_stations


def run(
    data_root: Path,
    band_name: str,
    rank: int,
    n_observed: int,
    seed: int,
    event_index: int,
    train_fraction: float,
    regularization: float,
    station_mapping_csv: Path,
    output_path: Path,
) -> None:
    band = FREQUENCY_BANDS[band_name]
    records = discover_processed_events(data_root, event_class=DEFAULT_EVENT_CLASS)
    train_records, val_records = split_records(
        records, train_fraction=train_fraction, seed=seed
    )

    if event_index >= len(val_records):
        raise ValueError(
            f"event_index {event_index} out of range; only {len(val_records)} val events"
        )
    target_record = val_records[event_index]
    print(f"Representative event: {target_record.path.name}")

    train_matrix = assemble_snapshot_matrix(train_records, band=band)
    basis, _ = compute_pod_basis(train_matrix, rank=rank)
    n_stations = train_matrix.shape[0] // N_COMPONENTS

    snapshots = load_bandpassed_snapshots(target_record, band=band)
    pgv_reference = pgv_from_snapshots(snapshots, dt=DEFAULT_DT_SECONDS)
    coords = station_coords_km(n_stations)

    ncsn_indices = load_mapped_station_indices(station_mapping_csv)
    layouts: dict[str, np.ndarray] = {
        "random": select_stations_random(
            n_stations, n_observed, np.random.default_rng(seed)
        ),
        "POD-QR": select_stations_pod_qr(
            pod_qr_station_order(basis, n_stations), n_observed, n_stations
        ),
        "NCSN-real": select_stations_ncsn(ncsn_indices, n_observed, n_stations),
    }

    layout_results: list[tuple[np.ndarray, np.ndarray, float]] = []
    hidden_err_samples: list[np.ndarray] = []
    for obs_stations in layouts.values():
        pgv_recon, _ = _reconstruct_layout(
            basis, snapshots, obs_stations, regularization, dt=DEFAULT_DT_SECONDS
        )
        rel_err = np.abs(pgv_recon - pgv_reference) / (pgv_reference + 1e-8)
        rel_err_hidden = rel_err.copy()
        rel_err_hidden[obs_stations] = np.nan
        hidden_err_samples.append(rel_err_hidden[~np.isnan(rel_err_hidden)])
        layout_results.append(
            (obs_stations, rel_err_hidden, float(np.nanmean(rel_err_hidden)))
        )

    pooled_hidden = np.concatenate(hidden_err_samples)
    vmax_err = float(np.clip(np.nanpercentile(pooled_hidden, 96), 0.35, 1.25))
    err_norm = mcolors.PowerNorm(gamma=0.55, vmin=0.0, vmax=vmax_err)
    print(f"Shared error colour scale: vmax={vmax_err:.3f} (96th pct, power gamma=0.55)")

    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
            "font.size": 11,
            "axes.labelsize": 11,
            "axes.titlesize": 11,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "font.weight": "normal",
            "axes.titleweight": "normal",
        }
    )

    fig, axes = plt.subplots(2, 2, figsize=(11, 6.4))
    fig.subplots_adjust(left=0.08, right=0.97, top=0.92, bottom=0.10,
                        wspace=0.42, hspace=0.38)
    cmap_ref = plt.get_cmap("YlOrRd").copy()
    cmap_err = plt.get_cmap("OrRd").copy()
    cmap_err.set_bad(color="#d8d8d8")
    scatter_kw = dict(s=1.0, linewidths=0, rasterized=True)
    obs_kw = dict(
        s=20,
        marker="^",
        c="k",
        linewidths=0.3,
        edgecolors="white",
        zorder=5,
        label="Observed stations",
    )
    panel_titles = [
        "(a) Reference PGV",
        f"(b) Random layout, rank {rank}, {n_observed} stations",
        f"(c) POD-QR layout, rank {rank}, {n_observed} stations",
        f"(d) NCSN-real layout, rank {rank}, {n_observed} stations",
    ]

    def _style_map_ax(ax: plt.Axes, title: str) -> None:
        _draw_geo_background(ax)
        ax.set_xlim(-1, LX + 1)
        ax.set_ylim(-1, LY + 1)
        ax.set_aspect("equal", adjustable="box")
        ax.add_patch(mpatches.FancyBboxPatch(
            (0, 0), LX, LY, boxstyle="square,pad=0",
            fill=False, edgecolor="#888888", linewidth=0.5, zorder=2))
        ax.set_title(title, pad=4)
        ax.set_xlabel("Along-fault  (km)", labelpad=2)
        ax.set_ylabel("Across-fault  (km)", labelpad=2)

    def _add_colorbar(ax: plt.Axes, sc, label: str) -> None:
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.06)
        cb = fig.colorbar(sc, cax=cax)
        cb.set_label(label, fontsize=10)
        cb.ax.tick_params(labelsize=8.5)

    ax = axes[0, 0]
    _style_map_ax(ax, panel_titles[0])
    vmax_ref = float(np.percentile(pgv_reference, 99))
    sc = ax.scatter(
        coords[:, 0],
        coords[:, 1],
        c=pgv_reference,
        cmap=cmap_ref,
        vmin=0,
        vmax=vmax_ref,
        zorder=3,
        **scatter_kw,
    )
    _add_colorbar(ax, sc, "PGV (normalized)")

    panel_axes = [axes[0, 1], axes[1, 0], axes[1, 1]]
    for ax, (obs_stations, rel_err_hidden, mean_err), title in zip(
        panel_axes, layout_results, panel_titles[1:]
    ):
        _style_map_ax(ax, title)
        sc = ax.scatter(
            coords[:, 0],
            coords[:, 1],
            c=rel_err_hidden,
            cmap=cmap_err,
            norm=err_norm,
            zorder=3,
            **scatter_kw,
        )
        _add_colorbar(ax, sc, "Relative PGV error")
        ax.scatter(coords[obs_stations, 0], coords[obs_stations, 1], **obs_kw)
        ax.text(
            0.03,
            0.91,
            f"mean error: {mean_err:.3f}",
            transform=ax.transAxes,
            fontsize=9,
            va="top",
            ha="left",
            bbox=dict(fc="white", alpha=0.75, pad=2, edgecolor="none"),
        )

    axes[1, 1].legend(
        fontsize=9, loc="lower right", framealpha=0.85, markerscale=1.2, handletextpad=0.4
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {output_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=DATA_PROCESSED / "events")
    parser.add_argument("--band", choices=sorted(FREQUENCY_BANDS), default=DEFAULT_BAND)
    parser.add_argument("--rank", type=int, default=151)
    parser.add_argument("--n-observed", type=int, default=128)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--event-index",
        type=int,
        default=0,
        help="Index into sorted validation events (0 = first held-out)",
    )
    parser.add_argument("--train-fraction", type=float, default=0.8)
    parser.add_argument("--regularization", type=float, default=1e-8)
    parser.add_argument(
        "--station-mapping-csv", type=Path, default=DEFAULT_STATION_MAPPING
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=RESULTS_FIGURES / "spatial_pgv_error_map_rank151_128stations.pdf",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run(
        data_root=args.data_root,
        band_name=args.band,
        rank=args.rank,
        n_observed=args.n_observed,
        seed=args.seed,
        event_index=args.event_index,
        train_fraction=args.train_fraction,
        regularization=args.regularization,
        station_mapping_csv=args.station_mapping_csv,
        output_path=args.output,
    )


if __name__ == "__main__":
    main()
