"""Error-vs-station-count curves for gappy POD reconstruction.

Produces a two-panel figure (waveform error, PGV error) showing:
  - Random layout: mean ± 1-std shaded band across seeds
  - Farthest-point: single curve
  - POD-QR: single curve
  - NCSN (up to 144 stations): single curve, terminated at max count

Vertical annotations: OD=1 (n=151, full rank) and overdetermination
ratio OD=2.54 (n=384 = 2.54 × 151).

Usage
-----
    python -m src.plot_station_count_curves
    python -m src.plot_station_count_curves --input-csv path/to/sweep.csv
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd

from .config import RESULTS_TABLES

DEFAULT_INPUT = RESULTS_TABLES / "station_count_sweep_mw7_lowfreq.csv"
DEFAULT_OUTPUT = Path("results/figures/station_count_curves_mw7_lowfreq.pdf")

RANK = 151
N_COMP = 3
OD1_N = round(RANK / N_COMP)          # n_obs s.t. n_obs*3 = rank → 50
OD2_54_N = round(2.54 * RANK / N_COMP)  # n_obs s.t. n_obs*3 ≈ 2.54*rank → 128

LAYOUT_STYLES = {
    "random":   {"color": "#1f77b4", "label": "Random (mean ± std)"},
    "farthest": {"color": "#d62728", "label": "Farthest-point", "ls": "--"},
    "pod_qr":   {"color": "#2ca02c", "label": r"POD-QR ($n_\mathrm{modes}=50$)", "ls": "-."},
    "ncsn":     {"color": "#9467bd", "label": "NCSN real",        "ls": ":"},
}


def _load(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    return df


def _random_stats(df: pd.DataFrame, metric: str) -> pd.DataFrame:
    sub = df[df["layout"] == "random"]
    stats = (
        sub.groupby("n_observed_stations")[metric]
        .agg(["mean", "std"])
        .reset_index()
    )
    return stats


def _single_curve(df: pd.DataFrame, layout: str, metric: str) -> pd.DataFrame:
    sub = df[df["layout"] == layout].sort_values("n_observed_stations")
    return sub[["n_observed_stations", metric]]


def plot(input_csv: Path, output_path: Path) -> None:
    df = _load(input_csv)
    metrics = [
        ("mean_rel_error_heldout",  "Relative waveform error (heldout)"),
        ("mean_pgv_error_heldout",  "Relative PGV error (heldout)"),
    ]

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), sharey=False)

    for ax, (metric, ylabel) in zip(axes, metrics):
        # Random band
        rand = _random_stats(df, metric)
        if not rand.empty:
            st = LAYOUT_STYLES["random"]
            ax.plot(rand["n_observed_stations"], rand["mean"],
                    color=st["color"], lw=1.8, zorder=3)
            ax.fill_between(
                rand["n_observed_stations"],
                rand["mean"] - rand["std"],
                rand["mean"] + rand["std"],
                color=st["color"], alpha=0.18, zorder=2,
            )

        # Deterministic layouts
        for layout in ["farthest", "pod_qr", "ncsn"]:
            curve = _single_curve(df, layout, metric)
            if curve.empty:
                continue
            st = LAYOUT_STYLES[layout]
            ax.plot(
                curve["n_observed_stations"], curve[metric],
                color=st["color"], ls=st.get("ls", "-"),
                lw=1.8, zorder=3,
            )

        # Vertical reference lines
        ymax = ax.get_ylim()[1] or 1.0
        ax.axvline(OD1_N, color="black", ls=":", lw=0.9, alpha=0.7)
        ax.axvline(OD2_54_N, color="black", ls="--", lw=0.9, alpha=0.7)
        ax.text(OD1_N + 4, 0.04, f"OD=1\n(n={OD1_N})",
                fontsize=7, va="bottom", color="black", alpha=0.8)
        ax.text(OD2_54_N + 4, 0.04, f"OD=2.54\n(n={OD2_54_N})",
                fontsize=7, va="bottom", color="black", alpha=0.8)

        ax.set_xlabel("Number of observed stations", fontsize=11)
        ax.set_ylabel(ylabel, fontsize=11)
        ax.set_xlim(left=0)
        ax.set_ylim(bottom=0)
        ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.5)
        ax.tick_params(labelsize=9)

    # Legend on first axis
    handles = []
    for key, st in LAYOUT_STYLES.items():
        if key == "random":
            patch = mpatches.Patch(color=st["color"], alpha=0.55, label=st["label"])
            handles.append(patch)
        else:
            line = matplotlib.lines.Line2D(
                [], [], color=st["color"], ls=st.get("ls", "-"), lw=1.8,
                label=st["label"],
            )
            handles.append(line)
    axes[0].legend(handles=handles, fontsize=8, loc="upper right")

    fig.suptitle(
        "Gappy POD reconstruction — station-count sweep\n"
        "(rank 151, low-frequency 0.02–0.25 Hz, Mw7)",
        fontsize=10,
    )
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    fig.savefig(output_path.with_suffix(".png"), dpi=150, bbox_inches="tight")
    print(f"Saved → {output_path}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input-csv",  type=Path, default=DEFAULT_INPUT)
    p.add_argument("--output-pdf", type=Path, default=DEFAULT_OUTPUT)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    plot(args.input_csv, args.output_pdf)


if __name__ == "__main__":
    main()
